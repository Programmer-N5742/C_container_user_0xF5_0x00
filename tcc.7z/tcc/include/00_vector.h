#ifndef VECTOR_H
#define VECTOR_H



#define def_vector(T) \
typedef struct vector_##T##_s\
{\
    uint32_t size;\
    T* data;\
} vector_##T;

#define vector(T) vector_##T

#define vector_construct(this) {this.size=0;}
/*#define vector_construct(this,S)\
{\
    this.size=S;\
    this.data = (typeof(data))malloc(sizeof(*this.data)*(this.size));\
}*/

#define vector_destruct(this) {if(this.data) free(this.data);}
#define vector_begin(this)   (this.data)
#define vector_end(this)     (this.data+size)
#define vector_push_back(this,n)\
{\
    if(this.size == 0)\
        {\
            ++this.size;\
            this.data = (typeof(this.data))malloc(sizeof(*this.data)*(this.size));\
            this.data[0] = n;\
        }\
        else\
        {\
            ++this.size;\
            this.data = (typeof(this.data))realloc(this.data,sizeof(*this.data)*(this.size));\
            this.data[this.size-1] = n;\
        }\
}


#define vector_index(this,index)  (this.data[index])


#endif //VECTOR_H
