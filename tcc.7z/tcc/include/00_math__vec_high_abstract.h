#ifndef MATH_VECTOR_HIGH_ABSTRACT_H
#define MATH_VECTOR_HIGH_ABSTRACT_H

#define _STANDART_PREC_MODE float

#define VEC1(_TYPE,_NAME, _N0) \
_TYPE NAME_##ARR[1] = {_N0}; \
v_decl(_TYPE*,_NAME,1) = v_new_arr(_NAME, NAME_##ARR)

#define VEC2(_TYPE,_NAME, _N0,_N1) \
_TYPE NAME_##ARR[2] = {_N0,_N1}; \
v_decl(_TYPE*,_NAME,2) = v_new_arr(_NAME, NAME_##ARR)

#define VEC3(_TYPE,_NAME, _N0,_N1,_N2) \
_TYPE NAME_##ARR[3] = {_N0,_N1,_N2}; \
v_decl(_TYPE*,_NAME,3) = v_new_arr(_NAME, NAME_##ARR)

#define VEC4(_TYPE,_NAME, _N0,_N1,_N2,_N3) \
_TYPE NAME_##ARR[4] = {_N0,_N1,_N2,_N3}; \
v_decl(_TYPE*,_NAME,4) = v_new_arr(_NAME, NAME_##ARR)

#define  vec1i8(NAME, N0)          VEC1(uint8_t ,NAME, N0)
#define vec1i16(NAME, N0)          VEC1(uint16_t,NAME, N0)
#define vec1i32(NAME, N0)          VEC1(uint32_t,NAME, N0)
#define vec1i64(NAME, N0)          VEC1(uint64_t,NAME, N0)
#define  vec1fs(NAME, N0)          VEC1(float   ,NAME, N0)
#define  vec1fd(NAME, N0)          VEC1(double  ,NAME, N0)
#define   vec1f(NAME, N0)          VEC1(_STANDART_PREC_MODE,NAME, N0)

#define  vec2i8(NAME, N0,N1)       VEC2(uint8_t ,NAME, N0,N1)
#define vec2i16(NAME, N0,N1)       VEC2(uint16_t,NAME, N0,N1)
#define vec2i32(NAME, N0,N1)       VEC2(uint32_t,NAME, N0,N1)
#define vec2i64(NAME, N0,N1)       VEC2(uint64_t,NAME, N0,N1)
#define  vec2fs(NAME, N0,N1)       VEC2(float   ,NAME, N0,N1)
#define  vec2fd(NAME, N0,N1)       VEC2(double  ,NAME, N0,N1)
#define   vec2f(NAME, N0,N1)       VEC2(_STANDART_PREC_MODE,NAME, N0,N1)

#define  vec3i8(NAME, N0,N1,N2)    VEC3(uint8_t ,NAME, N0,N1,N2)
#define vec3i16(NAME, N0,N1,N2)    VEC3(uint16_t,NAME, N0,N1,N2)
#define vec3i32(NAME, N0,N1,N2)    VEC3(uint32_t,NAME, N0,N1,N2)
#define vec3i64(NAME, N0,N1,N2)    VEC3(uint64_t,NAME, N0,N1,N2)
#define  vec3fs(NAME, N0,N1,N2)    VEC3(float   ,NAME, N0,N1,N2)
#define  vec3fd(NAME, N0,N1,N2)    VEC3(double  ,NAME, N0,N1,N2)
#define   vec3f(NAME, N0,N1,N2)    VEC3(_STANDART_PREC_MODE,NAME, N0,N1,N2)

#define  vec4i8(NAME, N0,N1,N2,N3) VEC4(uint8_t ,NAME, N0,N1,N2,N3)
#define vec4i16(NAME, N0,N1,N2,N3) VEC4(uint16_t,NAME, N0,N1,N2,N3)
#define vec4i32(NAME, N0,N1,N2,N3) VEC4(uint32_t,NAME, N0,N1,N2,N3)
#define vec4i64(NAME, N0,N1,N2,N3) VEC4(uint64_t,NAME, N0,N1,N2,N3)
#define  vec4fs(NAME, N0,N1,N2,N3) VEC4(float   ,NAME, N0,N1,N2,N3)
#define  vec4fd(NAME, N0,N1,N2,N3) VEC4(double  ,NAME, N0,N1,N2,N3)
#define   vec4f(NAME, N0,N1,N2,N3) VEC4(_STANDART_PREC_MODE,NAME, N0,N1,N2)


#define v_a(v0) for(i, v0##_dim)   v0[i]
#define v_b(v1) v1[i]; endfor(i)

#define vectorize(f, v0,v1) for(i, v0##_dim)   v0[i] = f(v0[i], v1[i]); endfor(i)



#endif //MATH_VECTOR_HIGH_ABSTRACT_H