#ifndef BINT_H
#define BINT_H

#include <00_main_terms.h>

//N0(TYPE, NAME, SIZE)
#define N0(T,N,S)\
    T N##_s = S;\
    T* N = (to(N)) ma(so(*N)*N##_s);\
    FOR(i,N##_s) N[i] = (to(*N))0;\
    T N##_BIE = bso(*N);\
    T N##_BC = so(N);

//N1(TYPE, NAME, ORIGIN)
#define N1(T,N,O)\
    T N##_s = O##_s;\
    T* N = (to(N)) ma(so(*N)*N##_s);\
    FOR(i,N##_s) N[i] = (to(*N))O[i];\
    T N##_BIE = bso(*N);\
    T N##_BC = so(N);

//N2(TYPE, NAME, SIZE, ARR)
#define N2(T,N,S,__VA_ARGS__...)\
    T N##_arr[S]={__VA_ARGS__};\
    T N##_s = S;\
    T* N = (to(N)) ma(so(*N)*N##_s);\
    FOR(i,N##_s) N[N##_s-1-i] = (to(*N))N##_arr[i];\
    T N##_BIE = bso(*N);\
    T N##_BC = so(N);

//N3(TYPE, NAME, SIZE, FROM_ARR)
#define N3(T,N,S,FA)\
    T N##_s = S;\
    T* N = (to(N)) ma(so(*N)*N##_s);\
    FOR(i,N##_s) N[N##_s-1-i] = (to(*N))FA[i];\
    T N##_BIE = bso(*N);\
    T N##_BC = so(N);

#define printN(N) FOR(i,N##_s) print("\t%d", N[N##_s-1-i]);


#define BInt_d(type, a) type* a, type a##_s, type a##_BIE, type a##_BC
#define BInt_in(a) a, a##_s, a##_BIE, a##_BC

#define Ncopy(N,O) FOR(i,N##_s) N[i]=O[i];
#define Nmove(N,O) N = O;
#define Ninv_1cmpl(N) FOR(i,N##_s) N[i]=~N[i];
//#define Ninv_2cmpl(N) FOR(i,N##_s) N[i]=~O[i]; N+=1;

#ifndef BBIT
#define BBIT       _u8 //BaseBIntType
#endif //BBIT

#ifndef BBIS
#define BBIS         4 //BaseBIntSize
#endif //BBIS

#define BN0(N)      N0(BBIT,N,BBIS)
#define BN1(N,O)    N1(BBIT,N,O)
#define BN2(N,A)    N2(BBIT,N,BBIS,A)
#define BN3(N,FA)   N3(BBIT,N,BBIS,FA)
//#define printI(I)  printN(I)
//#define Icopy(I,O) Ncopy(I,O)


_u8 Nret_size;

int z_add = 0;
_u8* bint_sum(BInt_d(const _u8, a), BInt_d(const _u8, b))
{
    N0(_u8,r, a_s);
    z_add = 0;
    FOR(i, r_s)
    {
        r[i] = a[i] + b[i] + z_add;
        if(
            ((_u8)(a[i] + b[i] + z_add) < a[i])
            ||
            ((_u8)(a[i] + b[i] + z_add) < b[i])
            ||
            ((_u8)(a[i] + b[i] + z_add) < z_add)

            ||

            ((_u8)(a[i] + b[i]) < a[i]) || ((_u8)(a[i] + b[i]) < b[i])
            ||
            ((_u8)(a[i] + z_add) < a[i]) || ((_u8)(a[i] + z_add) < z_add)
            ||
            ((_u8)(b[i] + z_add) < b[i]) || ((_u8)(b[i] + z_add) < z_add)
        ) z_add = 1; else z_add = 0;
    }
    Nret_size = r_s;
    __ r;
}

_u8* bint_diff(BInt_d(const _u8, a), BInt_d(const _u8, b))
{
    N0(_u8,r, a_s);
    z_add = 0;
    FOR(i, r_s)
    {
        r[i] = a[i] - b[i] - z_add;
        if(
           ((_u8)(a[i] - b[i] - z_add) > a[i])
           ) z_add = 1; else z_add = 0;
    }
    Nret_size = r_s;
    __ r;
}

#define bint_add(a,b) Nmove(a,bint_sum(BInt_in(a),BInt_in(b)))
#define bint_sub(a,b) Nmove(a,bint_diff(BInt_in(a),BInt_in(b)))

struct_func BBIT* bint_get_byte_bin_str(BInt_d(const _u8, a), int element)
{
    BBIT* result = (typeof(result)) malloc((sizeof(*result) * a_BIE) + 1);
    FOR(index, a_BIE)
    {
        result[a_BIE-index-1] = ((a[element] >> index) & 1)? '1' : '0';
    }
    result[a_BIE] = 0;
    return result;
}

struct_func BBIT* bint_get_bytes_bin_str_with_separator(BInt_d(const _u8, a))
{
    BBIT* result;
    int max_str_length = ((((sizeof(*result) * a_BIE) + 1) * a_s)-1);
    result = (typeof(result)) malloc(max_str_length + 1);
    FOR(element, a_s)
    {
        for(int index = (a_BIE)-1; index >= 0; --index)
        {
            result[max_str_length-(element*a_BIE+1+(element)+index)] = ((a[element] >> index) & 1)? '1' : '0';
        }
        result[(a_BIE * element)+(element)-1] = '_';
    }
    result[max_str_length] = 0;
    return result;
}

struct_func BBIT* bint_get_bytes_bin_str(BInt_d(const _u8, a))
{
    BBIT* result;
    int max_str_length = a_BIE*a_s;//((sizeof(*result) * a_BIE));
    result = (typeof(result)) malloc(max_str_length);
    //FOR(i,max_str_length) result[i] = 'N';
    FOR(element, a_s)
    {
        FOR(index, a_BIE)
        {
            result[a_BIE*element+a_BIE-index-1] = ((a[a_s-element-1] >> index) & 1)? '1' : '0';
        }
    }
    result[max_str_length] = 0;
    return result;
}

#endif //BINT_h
