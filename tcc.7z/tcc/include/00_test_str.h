char_t* strstr0(const char_t* str, const char_t* substr)
{
    asm("nop\n");asm("nop\n");asm("nop\n");asm("nop\n");asm("nop\n");
    if(*substr == 0) return str;
    const char_t* a;
    const char_t* b = substr;
    for(; *str; ++str)
    {
        if(*str != *b) continue;
        a = str;
        while(1)
        {
            if(*b == 0) return str;
            if(*a++ != *b++) break;
        }
        b = substr;
    }
    return NULL;
}

char_t* strstr1(const char_t* str, const char_t* substr)
{
    asm("nop\n");asm("nop\n");asm("nop\n");
    iter_t i;
    logic_t t;
    if(*substr == 0) /*{P("��������� �����\n");*/ return str;//} //���� ��������� ������(������ � \0) �� ������� ������
    while(*str) //���� �� ���������� �������� ������
    {
        //P("������ ������ ������ %c\n", *str);
        if(*substr == *str) //���� ������� ������� ��������� ������ � ������
        {
            t = 1;
            i = 0;
            while(substr[i])
            {
                t &= (substr[i] == str[i]);
                ++i;
            }
            if(t) {return str;}
        }
        ++str;
    }
    return NULLPTR;
}

char_t* strstr2(const char_t* str, const char_t* substr)
{
    asm("nop\n");asm("nop\n");asm("nop\n");asm("nop\n");asm("nop\n");asm("nop\n");asm("nop\n");asm("nop\n");asm("nop\n");
    char_t* str_backup = str;
    if(*substr == 0) /*{P("��������� �����\n");*/ return str;//} //���� ��������� ������(������ � \0) �� ������� ������
    while(*str) //���� �� ���������� �������� ������
    {
        //P("������ ������ ������ %c\n", *str);
        if(*substr == *str)
        {
            str_backup = str-1;
            while(1) //���� ������� ������� ��������� ������ � ������
            {
                if(*substr == 0) {str = str_backup; return str;}
                if(*str != *substr) break;
                ++str; ++substr;
            }
        }
        ++str;
    }
    return NULLPTR;
}

char_t* strstr3(const char_t* str, const char_t* substr)
{
    char_t* a = str;
    char_t* b = substr;
    while(1)
    {
        if(!*b) return str;
        if(!*a) return NULLPTR;
        if(*a++ != *b++) {a = ++str; b = substr;}
    }
}

char_t* strstr4(const char_t* str, const char_t* substr)
{
    char_t* a = str;
    char_t* b = substr;
    while(1)
    {
        if(!*b) return str;
        if(!*a) return NULLPTR;
        if(*a != *b) {a = ++str; b = substr;}
        a++;*b++;
    }
}


char_t* strstr5(const char_t* str, const char_t* substr)
{
    char_t* a;
    char_t* b = substr;
    if(!*b) return str;
    for(; *str; ++str)
    {
        if(*str != *b) continue;
        a = str;
        while(1)
        {
          if(!*b) return str;
          if(*a++ != *b++) break;
        }
        b = substr;
  }
  return NULLPTR;
}

lib_func char_t* str_substr6(const char_t* str, const char_t* substr)
{
    cnt_t n = strlen(substr);
    while(*str) if(!memcmp(str++,substr,n)) return str-1;
    return 0;
}

char_t* strstr7(char_t* word, char_t* in)
{
    int s; //iter_start
    int w; //iter_word
    logic_t t;
    s = 0;
    while(in[s])
    {
        if(word[0]==in[s])
        {
            t = 1;
            w = 0;
            while(word[w])
            {
                t &= (word[w] == in[s+w]);
                ++w;
            }
            if(t) return in+s;
        }
        ++s;
    }
    return -1;
}




char_t* strchr0(const char_t* str, char_t ch)
{
    while(*str)
    {
        if(ch == *str) return str;
        ++str;
    }
}

char_t* strchr1(const char_t* str, char_t ch)
{
    uiter_t i = 0;
    while(str[i])
    {
        if(str[i] == ch) return str+i;
        ++i;
    }
}


char_t* str_replace0(char_t* text, char_t* rep, char_t* with)
{
	int count = 0;											 // to compare the length of rep and with
	int textLen = strlen(text);								 // length of text
	int repLen = strlen(rep);								 // length of the text to be replaced
	int withLen = strlen(with);								 // length of the text to replace with
	char_t* copyText = (char_t* )malloc(sizeof(char_t) * textLen); // copy of text to save a copy for later use
	strcpy(copyText, text);
	for (int i = 0; i < textLen; i++)
	{
		// check if the new text occur in the old text
		for (int j = 0; j < repLen; j++)
		{
			if (text[i + j] == rep[j])
			{
				count++;
			}
		}
		// if count matches the old text length then replace the old text with the new text
		if (count == repLen)
		{
			// alter the occurence of the old text with the new text
			for (int j = 0; j < withLen; j++)
			{
				text[i + j] = with[j];
			}
			// if the lengths do not match then shift the text accordingly
			if (withLen != repLen)
			{
				int diff = withLen - repLen;
				// increment the text length by the difference
				textLen += diff;
				// the shift will not be done before the occurence of the old text
				// that is why (i + newLen) is subtracted from the text length
				// to shift the string terminator, 1 is added
				for (int j = 0; j < textLen - (i + withLen) + 1; j++)
				{
					// (i + newLen) is where the shift will start and j is to iterate through the text
					// copyText is the string that remains unchanged from the previous operation
					// the uncganged part starts at i + oldLen in the copyText
					text[(i + withLen) + j] = copyText[(i + repLen) + j];
				}
			}
			strcpy(copyText, text);
			// iterate i to skip the replaced text
			// -1 to cancel the increment in the for loop
			i += withLen - 1;
		}
		// reset count
		count = 0;
	}
	free(copyText); // deallocate the memory
	return text;
}

char_t* str_replace1(char_t* orig, char_t* rep, char_t* with)
{
    char_t* result;
    char_t* ins;
    char_t* tmp;
    int len_rep;
    int len_with;
    int len_front;
    int count;

    if (!orig)
        return NULL;
    if (!rep)
        rep = "";
    len_rep = strlen(rep);
    if (!with)
        with = "";
    len_with = strlen(with);

    ins = orig;
    for (count = 0; (tmp = strstr(ins, rep)); ++count) {
        ins = tmp + len_rep;
    }

    tmp = result = malloc(strlen(orig) + (len_with - len_rep) * count + 1);

    if (!result)
        return NULL;

    while (count--) {
        ins = strstr(orig, rep);
        len_front = ins - orig;
        tmp = strncpy(tmp, orig, len_front) + len_front;
        tmp = strcpy(tmp, with) + len_with;
        orig += len_front + len_rep;
    }
    strcpy(tmp, orig);
    return result;
}

int indexOf(char_t* str, char_t* c) {
    char_t* pointer = strlen(c) > 1
        ? strstr(str, c)
        : strchr(str, c[0]);

    if (pointer == NULL) {
        return -1;
    }

    return pointer - str;
}

/**
 * Replaces the first occurrence of the searched string in the subject string.
 *
 * @param search The substring to look for
 * @param replace The substring with which to replace the found substring
 * @param subject The string in which to look
 *
 * @return A new string with the search/replacement performed
 **/
char_t* str_replace3(char_t* subject, char_t* search, char_t* replace) {
    int suffix_len, result_len, search_len, replace_len, subject_len, index;
    char_t* result, *prefix, *suffix;

    search_len = strlen(search);
    subject_len = strlen(subject);
    index = indexOf(subject, search);

    if (search_len == 0 || index < 0) {
        result = malloc(subject_len + 1);
        strncpy(result, subject, subject_len + 1);

        return result;
    }

    prefix = malloc(index + 1);
    strncpy(prefix, subject, index);

    suffix_len = subject_len - (index + search_len);
    suffix = malloc(suffix_len + 1);
    strncat(suffix, subject + index + search_len, suffix_len);//+ � ????

    replace_len = strlen(replace);
    result_len = strlen(prefix) + replace_len + suffix_len + 1;
    result = malloc(result_len + 1);
    snprintf(result, result_len, "%s%s%s", prefix, replace, suffix);

    free(prefix);
    free(suffix);

    return result;
}