

#ifdef _MSC_VER
#define STBI_NOTUSED(v)  (void)(v)
#else
#define STBI_NOTUSED(v)  (void)sizeof(v)
#endif

static int zstdio_read(void *user, char* data, int size) {return (int) fread(data,1,size,(FILE*) user);}

static void zstdio_skip(void *user, int n)
{
   int ch;
   fseek((FILE*) user, n, SEEK_CUR);
   ch = fgetc((FILE*) user);  /* have to read a byte to reset feof()'s flag */
   if(ch != EOF) {
      ungetc(ch, (FILE *) user);  /* push byte back onto stream if valid. */
   }
}

static int zstdio_eof(void *user) {return feof((FILE*) user) || ferror((FILE *) user);}

typedef struct
{
   int      (*read)  (void *user,char* data,int size);   // fill 'data' with 'size' bytes.  return number of bytes actually read
   void     (*skip)  (void *user,int n);                 // skip the next 'n' bytes, or 'unget' the last -n bytes if negative
   int      (*eof)   (void *user);                       // returns nonzero if we are at end of file/data
} stbi_io_callbacks;

enum
{
   STBI_ORDER_RGB,
   STBI_ORDER_BGR
};
typedef struct
{
   int bits_per_channel;
   int num_channels;
   int channel_order;
} zresult_info;
static stbi_io_callbacks zstdio_callbacks =
{
   zstdio_read,
   zstdio_skip,
   zstdio_eof,
};

typedef struct
{
   uint32_t img_x, img_y;
   int img_n, img_out_n;

   stbi_io_callbacks io;
   void* io_user_data;

   int read_from_callbacks;
   int buflen;
   uint8_t buffer_start[128];
   int callback_already_read;

   uint8_t* img_buffer, *img_buffer_end;
   uint8_t* img_buffer_original, *img_buffer_original_end;
} zcontext;

static void zrefill_buffer(zcontext* s)
{
   int n = (s->io.read)(s->io_user_data,(char*)s->buffer_start,s->buflen);
   s->callback_already_read += (int) (s->img_buffer - s->img_buffer_original);
   if(n == 0) {
      // at end of file, treat same as if from memory, but need to handle case
      // where s->img_buffer isn't pointing to safe memory, e.g. 0-byte file
      s->read_from_callbacks = 0;
      s->img_buffer = s->buffer_start;
      s->img_buffer_end = s->buffer_start+1;
      *s->img_buffer = 0;
   } else {
      s->img_buffer = s->buffer_start;
      s->img_buffer_end = s->buffer_start + n;
   }
}
// Microsoft/Windows BMP image
inline static uint8_t zget8(zcontext* s)
{
   if(s->img_buffer < s->img_buffer_end)
      return *s->img_buffer++;
   if(s->read_from_callbacks) {
      zrefill_buffer(s);
      return *s->img_buffer++;
   }
   return 0;
}

#if defined(STBI_NO_BMP) && defined(STBI_NO_TGA) && defined(STBI_NO_GIF)
// nothing
#else
static int zget16le(zcontext* s)
{
   int z = zget8(s);
   return z + (zget8(s) << 8);
}
#endif

#ifndef STBI_NO_BMP
static uint32_t zget32le(zcontext* s)
{
   uint32_t z = zget16le(s);
   return z + (zget16le(s) << 16);
}
#endif

const char* zg_failure_reason;

const char* stbi_failure_reason(void)
{
   return zg_failure_reason;
}

#ifndef STBI_NO_FAILURE_STRINGS
static int zerr(const char* str)
{
   zg_failure_reason = str;
   return 0;
}
#endif


static int zaddsizes_valid(int a, int b)
{
   if(b < 0) return 0;
   // now 0 <= b <= INT_MAX, hence also
   // 0 <= INT_MAX - b <= INTMAX.
   // And "a + b <= INT_MAX" (which might overflow) is the
   // same as a <= INT_MAX - b (no overflow)
   return a <= INT_MAX - b;
}

// returns 1 if the product is valid, 0 on overflow.
// negative factors are considered invalid.
static int zmul2sizes_valid(int a, int b)
{
   if(a < 0 || b < 0) return 0;
   if(b == 0) return 1; // mul-by-0 is always safe
   // portable way to check for no overflows in a*b
   return a <= INT_MAX/b;
}

#if !defined(STBI_NO_JPEG) || !defined(STBI_NO_PNG) || !defined(STBI_NO_TGA) || !defined(STBI_NO_HDR)
// returns 1 if "a*b + add" has no negative terms/factors and doesn't overflow
static int zmad2sizes_valid(int a, int b, int add)
{
   return zmul2sizes_valid(a, b) && zaddsizes_valid(a*b, add);
}
#endif

// returns 1 if "a*b*c + add" has no negative terms/factors and doesn't overflow
static int zmad3sizes_valid(int a, int b, int c, int add)
{
   return zmul2sizes_valid(a, b) && zmul2sizes_valid(a*b, c) &&
      zaddsizes_valid(a*b*c, add);
}
// zerr - error
// zerrpf - error returning pointer to float
// zerrpuc - error returning pointer to uint8_t

#ifdef STBI_NO_FAILURE_STRINGS
   #define zerr(x,y)  0
#elif defined(STBI_FAILURE_USERMSG)
   #define zerr(x,y)  zerr(y)
#else
   #define zerr(x,y)  zerr(x)
#endif

#define zerrpf(x,y)   ((float *)(size_t) (zerr(x,y)?NULL:NULL))
#define zerrpuc(x,y)  ((uint8_t* )(size_t) (zerr(x,y)?NULL:NULL))

void stbi_image_free(void *retval_from_stbi_load)
{
   free(retval_from_stbi_load);
}



static int zvertically_flip_on_load_global = 0;

void stbi_set_flip_vertically_on_load(int flag_true_if_should_flip)
{
   zvertically_flip_on_load_global = flag_true_if_should_flip;
}

#ifndef STBI_THREAD_LOCAL
#define zvertically_flip_on_load  zvertically_flip_on_load_global
#else
static STBI_THREAD_LOCAL int zvertically_flip_on_load_local, zvertically_flip_on_load_set;

void stbi_set_flip_vertically_on_load_thread(int flag_true_if_should_flip)
{
   zvertically_flip_on_load_local = flag_true_if_should_flip;
   zvertically_flip_on_load_set = 1;
}

#define zvertically_flip_on_load  (zvertically_flip_on_load_set       \
                                         ? zvertically_flip_on_load_local  \
                                         : zvertically_flip_on_load_global)
#endif // STBI_THREAD_LOCAL



#ifndef STBI_NO_BMP
static int      zbmp_test(zcontext* s);
static void    *zbmp_load(zcontext* s, int* x, int* y, int* comp, int req_comp, zresult_info *ri);
static int      zbmp_info(zcontext* s, int* x, int* y, int* comp);
#endif


static void zrewind(zcontext* s)
{
   // conceptually rewind SHOULD rewind to the beginning of the stream,
   // but we just rewind to the beginning of the initial buffer, because
   // we only use it after doing 'test', which only ever looks at at most 92 bytes
   s->img_buffer = s->img_buffer_original;
   s->img_buffer_end = s->img_buffer_original_end;
}
// Microsoft/Windows BMP image

#ifndef STBI_NO_BMP
static int zbmp_test_raw(zcontext* s)
{
   int r;
   int sz;
   if(zget8(s) != 'B') return 0;
   if(zget8(s) != 'M') return 0;
   zget32le(s); // discard filesize
   zget16le(s); // discard reserved
   zget16le(s); // discard reserved
   zget32le(s); // discard data offset
   sz = zget32le(s);
   r = (sz == 12 || sz == 40 || sz == 56 || sz == 108 || sz == 124);
   return r;
}

static int zbmp_test(zcontext* s)
{
   int r = zbmp_test_raw(s);
   zrewind(s);
   return r;
}


// returns 0..31 for the highest set bit
static int zhigh_bit(uint32_t z)
{
   int n=0;
   if(z == 0) return -1;
   if(z >= 0x10000) {n += 16; z >>= 16;}
   if(z >= 0x00100) {n +=  8; z >>=  8;}
   if(z >= 0x00010) {n +=  4; z >>=  4;}
   if(z >= 0x00004) {n +=  2; z >>=  2;}
   if(z >= 0x00002) {n +=  1;/*z >>=  1;*/}
   return n;
}

static int zbitcount(uint32_t a)
{
   a = (a & 0x55555555) + ((a >>  1) & 0x55555555); // max 2
   a = (a & 0x33333333) + ((a >>  2) & 0x33333333); // max 4
   a = (a + (a >> 4)) & 0x0f0f0f0f; // max 8 per 4, now 8 bits
   a = (a + (a >> 8)); // max 16 per 8 bits
   a = (a + (a >> 16)); // max 32 per 8 bits
   return a & 0xff;
}

// extract an arbitrarily-aligned N-bit value (N=bits)
// from v, and then make it 8-bits long and fractionally
// extend it to full full range.
static int zshiftsigned(uint32_t v, int shift, int bits)
{
   static uint32_t mul_table[9] = {
      0,
      0xff/*0b11111111*/, 0x55/*0b01010101*/, 0x49/*0b01001001*/, 0x11/*0b00010001*/,
      0x21/*0b00100001*/, 0x41/*0b01000001*/, 0x81/*0b10000001*/, 0x01/*0b00000001*/,
   };
   static uint32_t shift_table[9] = {
      0, 0,0,1,0,2,4,6,0,
   };
   if(shift < 0)
      v <<= -shift;
   else
      v >>= shift;
   //STBI_ASSERT(v < 256);
   v >>= (8-bits);
   //STBI_ASSERT(bits >= 0 && bits <= 8);
   return (int) ((unsigned) v * mul_table[bits]) >> shift_table[bits];
}

typedef struct
{
   int bpp, offset, hsz;
   uint32_t mr,mg,mb,ma, all_a;
   int extra_read;
} zbmp_data;

static void *zbmp_parse_header(zcontext* s, zbmp_data *info)
{
   int hsz;
   if(zget8(s) != 'B' || zget8(s) != 'M') return zerrpuc("not BMP", "Corrupt BMP");
   zget32le(s); // discard filesize
   zget16le(s); // discard reserved
   zget16le(s); // discard reserved
   info->offset = zget32le(s);
   info->hsz = hsz = zget32le(s);
   info->mr = info->mg = info->mb = info->ma = 0;
   info->extra_read = 14;

   if(info->offset < 0) return zerrpuc("bad BMP", "bad BMP");

   if(hsz != 12 && hsz != 40 && hsz != 56 && hsz != 108 && hsz != 124) return zerrpuc("unknown BMP", "BMP type not supported: unknown");
   if(hsz == 12) {
      s->img_x = zget16le(s);
      s->img_y = zget16le(s);
   } else {
      s->img_x = zget32le(s);
      s->img_y = zget32le(s);
   }
   if(zget16le(s) != 1) return zerrpuc("bad BMP", "bad BMP");
   info->bpp = zget16le(s);
   if(hsz != 12) {
      int compress = zget32le(s);
      if(compress == 1 || compress == 2) return zerrpuc("BMP RLE", "BMP type not supported: RLE");
      zget32le(s); // discard sizeof
      zget32le(s); // discard hres
      zget32le(s); // discard vres
      zget32le(s); // discard colorsused
      zget32le(s); // discard max important
      if(hsz == 40 || hsz == 56) {
         if(hsz == 56) {
            zget32le(s);
            zget32le(s);
            zget32le(s);
            zget32le(s);
         }
         if(info->bpp == 16 || info->bpp == 32) {
            if(compress == 0) {
               if(info->bpp == 32) {
                  info->mr = 0xffu << 16;
                  info->mg = 0xffu <<  8;
                  info->mb = 0xffu <<  0;
                  info->ma = 0xffu << 24;
                  info->all_a = 0; // if all_a is 0 at end, then we loaded alpha channel but it was all 0
               } else {
                  info->mr = 31u << 10;
                  info->mg = 31u <<  5;
                  info->mb = 31u <<  0;
               }
            } else if(compress == 3) {
               info->mr = zget32le(s);
               info->mg = zget32le(s);
               info->mb = zget32le(s);
               info->extra_read += 12;
               // not documented, but generated by photoshop and handled by mspaint
               if(info->mr == info->mg && info->mg == info->mb) {
                  // ?!?!?
                  return zerrpuc("bad BMP", "bad BMP");
               }
            } else
               return zerrpuc("bad BMP", "bad BMP");
         }
      } else {
         int i;
         if(hsz != 108 && hsz != 124) return zerrpuc("bad BMP", "bad BMP");
         info->mr = zget32le(s);
         info->mg = zget32le(s);
         info->mb = zget32le(s);
         info->ma = zget32le(s);
         zget32le(s); // discard color space
         for(i=0; i < 12; ++i) zget32le(s); // discard color space parameters
         if(hsz == 124) {
            zget32le(s); // discard rendering intent
            zget32le(s); // discard offset of profile data
            zget32le(s); // discard size of profile data
            zget32le(s); // discard reserved
         }
      }
   }
   return (void *) 1;
}

static void *zmalloc_mad3(int a, int b, int c, int add)
{
   if(!zmad3sizes_valid(a, b, c, add)) return NULL;
   return malloc(a*b*c + add);
}
#if defined(STBI_NO_JPEG) && defined(STBI_NO_PNG) && defined(STBI_NO_BMP) && defined(STBI_NO_PSD) && defined(STBI_NO_TGA) && defined(STBI_NO_GIF) && defined(STBI_NO_PIC)
// nothing
#else
static void zskip(zcontext* s, int n)
{
   if(n == 0) return;  // already there!
   if(n < 0) {
      s->img_buffer = s->img_buffer_end;
      return;
   }
   if(s->io.read) {
      int blen = (int) (s->img_buffer_end - s->img_buffer);
      if(blen < n) {
         s->img_buffer = s->img_buffer_end;
         (s->io.skip)(s->io_user_data, n - blen);
         return;
      }
   }
   s->img_buffer += n;
}
#if defined(STBI_NO_JPEG) && defined(STBI_NO_PNG) && defined(STBI_NO_BMP) && defined(STBI_NO_PSD) && defined(STBI_NO_TGA) && defined(STBI_NO_GIF) && defined(STBI_NO_PIC) && defined(STBI_NO_PNM)
// nothing
#else
static uint8_t zcompute_y(int r, int g, int b)
{
   return (uint8_t) (((r*77) + (g*150) +  (29*b)) >> 8);
}
#endif
#define zBYTECAST(x)  ((uint8_t) ((x) & 255))  // truncate int to byte without warnings
#if defined(STBI_NO_PNG) && defined(STBI_NO_BMP) && defined(STBI_NO_PSD) && defined(STBI_NO_TGA) && defined(STBI_NO_GIF) && defined(STBI_NO_PIC) && defined(STBI_NO_PNM)
// nothing
#else
static uint8_t* zconvert_format(uint8_t* data, int img_n, int req_comp, uint32_t x, uint32_t y)
{
   int i,j;
   uint8_t* good;

   if(req_comp == img_n) return data;
   //STBI_ASSERT(req_comp >= 1 && req_comp <= 4);

   good = (uint8_t* ) zmalloc_mad3(req_comp, x, y, 0);
   if(good == NULL) {
      free(data);
      return zerrpuc("outofmem", "Out of memory");
   }

   for(j=0; j < (int) y; ++j) {
      uint8_t* src  = data + j * x * img_n   ;
      uint8_t* dest = good + j * x * req_comp;

      #define zCOMBO(a,b)  ((a)*8+(b))
      #define zCASE(a,b)   case zCOMBO(a,b): for(i=x-1; i >= 0; --i, src += a, dest += b)
      // convert source image with img_n components to one with req_comp components;
      // avoid switch per pixel, so use switch per scanline and massive macros
      switch (zCOMBO(img_n, req_comp)) {
         zCASE(1,2) { dest[0]=src[0]; dest[1]=255;                                     } break;
         zCASE(1,3) { dest[0]=dest[1]=dest[2]=src[0];                                  } break;
         zCASE(1,4) { dest[0]=dest[1]=dest[2]=src[0]; dest[3]=255;                     } break;
         zCASE(2,1) { dest[0]=src[0];                                                  } break;
         zCASE(2,3) { dest[0]=dest[1]=dest[2]=src[0];                                  } break;
         zCASE(2,4) { dest[0]=dest[1]=dest[2]=src[0]; dest[3]=src[1];                  } break;
         zCASE(3,4) { dest[0]=src[0];dest[1]=src[1];dest[2]=src[2];dest[3]=255;        } break;
         zCASE(3,1) { dest[0]=zcompute_y(src[0],src[1],src[2]);                   } break;
         zCASE(3,2) { dest[0]=zcompute_y(src[0],src[1],src[2]); dest[1] = 255;    } break;
         zCASE(4,1) { dest[0]=zcompute_y(src[0],src[1],src[2]);                   } break;
         zCASE(4,2) { dest[0]=zcompute_y(src[0],src[1],src[2]); dest[1] = src[3]; } break;
         zCASE(4,3) { dest[0]=src[0];dest[1]=src[1];dest[2]=src[2];                    } break;
         default: /*STBI_ASSERT(0);*/ free(data); free(good); return zerrpuc("unsupported", "Unsupported format conversion");
      }
      #undef zCASE
   }

   free(data);
   return good;
}
#endif
#endif
#ifndef STBI_MAX_DIMENSIONS
#define STBI_MAX_DIMENSIONS (1 << 24)
#endif
static void *zbmp_load(zcontext* s, int* x, int* y, int* comp, int req_comp, zresult_info *ri)
{
   uint8_t* out;
   uint32_t mr=0,mg=0,mb=0,ma=0, all_a;
   uint8_t pal[256][4];
   int psize=0,i,j,width;
   int flip_vertically, pad, target;
   zbmp_data info;
   STBI_NOTUSED(ri);

   info.all_a = 255;
   if(zbmp_parse_header(s, &info) == NULL)
      return NULL; // error code already set

   flip_vertically = ((int) s->img_y) > 0;
   s->img_y = abs((int) s->img_y);

   if(s->img_y > STBI_MAX_DIMENSIONS) return zerrpuc("too large","Very large image (corrupt?)");
   if(s->img_x > STBI_MAX_DIMENSIONS) return zerrpuc("too large","Very large image (corrupt?)");

   mr = info.mr;
   mg = info.mg;
   mb = info.mb;
   ma = info.ma;
   all_a = info.all_a;

   if(info.hsz == 12)
   {
      if(info.bpp < 24) psize = (info.offset - info.extra_read - 24) / 3;
   } else
   {
      if(info.bpp < 16) psize = (info.offset - info.extra_read - info.hsz) >> 2;
   }
   if(psize == 0) {
      //STBI_ASSERT(info.offset == s->callback_already_read + (int) (s->img_buffer - s->img_buffer_original));
      if(info.offset != s->callback_already_read + (s->img_buffer - s->buffer_start)) {
        return zerrpuc("bad offset", "Corrupt BMP");
      }
   }

   if(info.bpp == 24 && ma == 0xff000000) s->img_n = 3;
   else s->img_n = ma ? 4 : 3;
   if(req_comp && req_comp >= 3) target = req_comp;// we can directly decode 3 or 4
   else target = s->img_n; // if they want monochrome, we'll post-convert

   // sanity-check size
   if(!zmad3sizes_valid(target, s->img_x, s->img_y, 0)) return zerrpuc("too large", "Corrupt BMP");

   out = (uint8_t* ) zmalloc_mad3(target, s->img_x, s->img_y, 0);
   if(!out) return zerrpuc("outofmem", "Out of memory");
   if(info.bpp < 16) {
      int z=0;
      if(psize == 0 || psize > 256) { free(out); return zerrpuc("invalid", "Corrupt BMP"); }
      for(i=0; i < psize; ++i) {
         pal[i][2] = zget8(s);
         pal[i][1] = zget8(s);
         pal[i][0] = zget8(s);
         if(info.hsz != 12) zget8(s);
         pal[i][3] = 255;
      }
      zskip(s, info.offset - info.extra_read - info.hsz - psize * (info.hsz == 12 ? 3 : 4));
      if(info.bpp == 1) width = (s->img_x + 7) >> 3;
      else if(info.bpp == 4) width = (s->img_x + 1) >> 1;
      else if(info.bpp == 8) width = s->img_x;
      else { free(out); return zerrpuc("bad bpp", "Corrupt BMP"); }
      pad = (-width)&3;
      if(info.bpp == 1) {
         for(j=0; j < (int) s->img_y; ++j) {
            int bit_offset = 7, v = zget8(s);
            for(i=0; i < (int) s->img_x; ++i) {
               int color = (v>>bit_offset)&0x1;
               out[z++] = pal[color][0];
               out[z++] = pal[color][1];
               out[z++] = pal[color][2];
               if(target == 4) out[z++] = 255;
               if(i+1 == (int) s->img_x) break;
               if((--bit_offset) < 0) {
                  bit_offset = 7;
                  v = zget8(s);
               }
            }
            zskip(s, pad);
         }
      } else {
         for(j=0; j < (int) s->img_y; ++j) {
            for(i=0; i < (int) s->img_x; i += 2) {
               int v=zget8(s),v2=0;
               if(info.bpp == 4) {
                  v2 = v & 15;
                  v >>= 4;
               }
               out[z++] = pal[v][0];
               out[z++] = pal[v][1];
               out[z++] = pal[v][2];
               if(target == 4) out[z++] = 255;
               if(i+1 == (int) s->img_x) break;
               v = (info.bpp == 8) ? zget8(s) : v2;
               out[z++] = pal[v][0];
               out[z++] = pal[v][1];
               out[z++] = pal[v][2];
               if(target == 4) out[z++] = 255;
            }
            zskip(s, pad);
         }
      }
   } else {
      int rshift=0,gshift=0,bshift=0,ashift=0,rcount=0,gcount=0,bcount=0,acount=0;
      int z = 0;
      int easy=0;
      zskip(s, info.offset - info.extra_read - info.hsz);
      if(info.bpp == 24) width = 3 * s->img_x;
      else if(info.bpp == 16) width = 2*s->img_x;
      else /* bpp = 32 and pad = 0 */ width=0;
      pad = (-width) & 3;
      if(info.bpp == 24) {
         easy = 1;
      } else if(info.bpp == 32) {
         if(mb == 0xff && mg == 0xff00 && mr == 0x00ff0000 && ma == 0xff000000)
            easy = 2;
      }
      if(!easy) {
         if(!mr || !mg || !mb) {free(out); return zerrpuc("bad masks", "Corrupt BMP");}
         // right shift amt to put high bit in position #7
         rshift = zhigh_bit(mr)-7; rcount = zbitcount(mr);
         gshift = zhigh_bit(mg)-7; gcount = zbitcount(mg);
         bshift = zhigh_bit(mb)-7; bcount = zbitcount(mb);
         ashift = zhigh_bit(ma)-7; acount = zbitcount(ma);
         if(rcount > 8 || gcount > 8 || bcount > 8 || acount > 8) { free(out); return zerrpuc("bad masks", "Corrupt BMP"); }
      }
      for(j=0; j < (int) s->img_y; ++j) {
         if(easy) {
            for(i=0; i < (int) s->img_x; ++i) {
               uint8_t a;
               out[z+2] = zget8(s);
               out[z+1] = zget8(s);
               out[z+0] = zget8(s);
               z += 3;
               a = (easy == 2 ? zget8(s) : 255);
               all_a |= a;
               if(target == 4) out[z++] = a;
            }
         } else {
            int bpp = info.bpp;
            for(i=0; i < (int) s->img_x; ++i) {
               uint32_t v = (bpp == 16 ? (uint32_t) zget16le(s) : zget32le(s));
               uint32_t a;
               out[z++] = zBYTECAST(zshiftsigned(v & mr, rshift, rcount));
               out[z++] = zBYTECAST(zshiftsigned(v & mg, gshift, gcount));
               out[z++] = zBYTECAST(zshiftsigned(v & mb, bshift, bcount));
               a = (ma ? zshiftsigned(v & ma, ashift, acount) : 255);
               all_a |= a;
               if(target == 4) out[z++] = zBYTECAST(a);
            }
         }
         zskip(s, pad);
      }
   }

   // if alpha channel is all 0s, replace with all 255s
   if(target == 4 && all_a == 0)
      for(i=4*s->img_x*s->img_y-1; i >= 0; i -= 4)
         out[i] = 255;

   if(flip_vertically) {
      uint8_t t;
      for(j=0; j < (int) s->img_y>>1; ++j) {
         uint8_t* p1 = out +      j     *s->img_x*target;
         uint8_t* p2 = out + (s->img_y-1-j)*s->img_x*target;
         for(i=0; i < (int) s->img_x*target; ++i) {
            t = p1[i]; p1[i] = p2[i]; p2[i] = t;
         }
      }
   }

   if(req_comp && req_comp != target) {
      out = zconvert_format(out, target, req_comp, s->img_x, s->img_y);
      if(out == NULL) return out; // zconvert_format frees input on failure
   }

   *x = s->img_x;
   *y = s->img_y;
   if(comp) *comp = s->img_n;
   return out;
}
#endif

static FILE *zfopen(char const *filename, char const *mode)
{
   FILE *f;
#if defined(_MSC_VER) && defined(STBI_WINDOWS_UTF8)
   wchar_t wMode[64];
   wchar_t wFilename[1024];
	if(0 == MultiByteToWideChar(65001 /* UTF8 */, 0, filename, -1, wFilename, sizeof(wFilename)))
      return 0;

	if(0 == MultiByteToWideChar(65001 /* UTF8 */, 0, mode, -1, wMode, sizeof(wMode)))
      return 0;

#if _MSC_VER >= 1400
	if(0 != _wfopen_s(&f, wFilename, wMode))
		f = 0;
#else
   f = _wfopen(wFilename, wMode);
#endif

#elif defined(_MSC_VER) && _MSC_VER >= 1400
   if(0 != fopen_s(&f, filename, mode))
      f=0;
#else
   f = fopen(filename, mode);
#endif
   return f;
}

uint8_t* stbi_load            (char const *filename, int* x, int* y, int* channels_in_file, int desired_channels);
uint8_t* stbi_load_from_file  (FILE *f, int* x, int* y, int* channels_in_file, int desired_channels);
uint8_t* stbi_load(char const *filename, int* x, int* y, int* comp, int req_comp)
{
   FILE *f = zfopen(filename, "rb");
   uint8_t* result;
   if(!f) return zerrpuc("can't fopen", "Unable to open file");
   result = stbi_load_from_file(f,x,y,comp,req_comp);
   fclose(f);
   return result;
}

// initialize a callback-based context
static void zstart_callbacks(zcontext* s, stbi_io_callbacks *c, void *user)
{
   s->io = *c;
   s->io_user_data = user;
   s->buflen = sizeof(s->buffer_start);
   s->read_from_callbacks = 1;
   s->callback_already_read = 0;
   s->img_buffer = s->img_buffer_original = s->buffer_start;
   zrefill_buffer(s);
   s->img_buffer_original_end = s->img_buffer_end;
}


static void zstart_file(zcontext* s, FILE *f) {zstart_callbacks(s, &zstdio_callbacks, (void *) f);}



static void* zload_main(zcontext* s, int* x, int* y, int* comp, int req_comp, zresult_info* ri, int bpc)
{
   memset(ri, 0, sizeof(*ri)); // make sure it's initialized if we add new fields
   ri->bits_per_channel = 8; // default is 8 so most paths don't have to be changed
   ri->channel_order = STBI_ORDER_RGB; // all current input & output are this, but this is here so we can add BGR order
   ri->num_channels = 0;

   #ifndef STBI_NO_BMP
   if(zbmp_test(s))  return zbmp_load(s,x,y,comp,req_comp, ri);
   #endif

   return zerrpuc("unknown image type", "Image not of any known type, or corrupt");
}
static uint8_t* zconvert_16_to_8(uint16_t *orig, int w, int h, int channels)
{
   int i;
   int img_len = w * h * channels;
   uint8_t* reduced;

   reduced = (uint8_t* ) malloc(img_len);
   if(reduced == NULL) return zerrpuc("outofmem", "Out of memory");

   for(i = 0; i < img_len; ++i) reduced[i] = (uint8_t)((orig[i] >> 8) & 0xFF); // top half of each byte is sufficient approx of 16->8 bit scaling

   free(orig);
   return reduced;
}
static void zvertical_flip(void *image, int w, int h, int bytes_per_pixel)
{
   int row;
   size_t bytes_per_row = (size_t)w * bytes_per_pixel;
   uint8_t temp[2048];
   uint8_t* bytes = (uint8_t*)image;

   for(row = 0; row < (h>>1); ++row)
   {
      uint8_t* row0 = bytes + row*bytes_per_row;
      uint8_t* row1 = bytes + (h - row - 1)*bytes_per_row;
      // swap row0 with row1
      size_t bytes_left = bytes_per_row;
      while(bytes_left)
      {
         size_t bytes_copy = (bytes_left < sizeof(temp)) ? bytes_left : sizeof(temp);
         memcpy(temp, row0, bytes_copy);
         memcpy(row0, row1, bytes_copy);
         memcpy(row1, temp, bytes_copy);
         row0 += bytes_copy;
         row1 += bytes_copy;
         bytes_left -= bytes_copy;
      }
   }
}
static uint8_t* zload_and_postprocess_8bit(zcontext* s, int* x, int* y, int* comp, int req_comp)
{
   zresult_info ri;
   void *result = zload_main(s, x, y, comp, req_comp, &ri, 8);

   if(result == NULL) return NULL;

   // it is the responsibility of the loaders to make sure we get either 8 or 16 bit.
   //STBI_ASSERT(ri.bits_per_channel == 8 || ri.bits_per_channel == 16);

   if(ri.bits_per_channel != 8) {
      result = zconvert_16_to_8((uint16_t *) result, *x, *y, req_comp == 0 ? *comp : req_comp);
      ri.bits_per_channel = 8;
   }

   // @TODO: move zconvert_format to here

   if(zvertically_flip_on_load) {
      int channels = req_comp ? req_comp : *comp;
      zvertical_flip(result, *x, *y, channels * sizeof(uint8_t));
   }

   return (uint8_t*)result;
}
uint8_t* stbi_load_from_file(FILE *f, int* x, int* y, int* comp, int req_comp)
{
   uint8_t* result;
   zcontext s;
   zstart_file(&s,f);
   result = zload_and_postprocess_8bit(&s,x,y,comp,req_comp);
   if(result) {
      // need to 'unget' all the characters in the IO buffer
      fseek(f, - (int) (s.img_buffer_end - s.img_buffer), SEEK_CUR);
   }
   return result;
}
