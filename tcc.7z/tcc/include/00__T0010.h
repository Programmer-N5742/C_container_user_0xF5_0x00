#define CHAR        sint8_t
#define SHORT       sint16_t
#define LONG        sint32_t
#define LONGLONG    sint64_t

#define UCHAR       uint8_t
#define USHORT      uint16_t
#define ULONG       uint32_t
#define ULONGLONG   uint64_t

#define PCHAR       CHAR*
#define PSHORT      SHORT*
#define PLONG       LONG*
#define PLONGLONG   LONGLONG*

#define PUCHAR      UCHAR*
#define PUSHORT     USHORT*
#define PULONG      ULONG*
#define PULONGLONG  ULONGLONG*



#define TCHAR       sint8_t
#define TSHORT      sint16_t
#define TLONG       sint32_t
#define TLONGLONG   sint64_t

#define TSCHAR      sint8_t
#define TSSHORT     sint16_t
#define TSLONG      sint32_t
#define TSLONGLONG  sint64_t

#define TUCHAR      uint8_t
#define TUSHORT     uint16_t
#define TULONG      uint32_t
#define TULONGLONG  uint64_t


#define TPCHAR      TCHAR*
#define TPSHORT     TSHORT*
#define TPLONG      TLONG*
#define TPLONGLONG  TLONGLONG*

#define TPCHAR      TSCHAR*
#define TPSHORT     TSSHORT*
#define TPLONG      TSLONG*
#define TPLONGLONG  TSLONGLONG*

#define TPUCHAR     TUCHAR*
#define TPUSHORT    TUSHORT*
#define TPULONG     TULONG*
#define TPULONGLONG TULONGLONG*