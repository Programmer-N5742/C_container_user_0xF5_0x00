#ifndef STRBLDR_H
#define STRBLDR_H

#define strbldr_def(NAME)                uint32_t NAME##_s = 0; char* NAME
#define strbldr_create(NAME, FROM, SIZE) {NAME##_s += SIZE;    NAME = malloc(NAME##_s+1);        memcpy(NAME, FROM, SIZE);                    NAME[NAME##_s] = 0;}
#define strbldr_add(NAME, ADD, ADDSIZE)  {NAME##_s += ADDSIZE; NAME = realloc(NAME, NAME##_s+1); memcpy(NAME+NAME##_s-ADDSIZE, ADD, ADDSIZE); NAME[NAME##_s] = 0;}
#define strbldr_zadd(NAME, ADD, ADDSIZE) if(!NAME##_s) strbldr_create(NAME, ADD, ADDSIZE) else strbldr_add(NAME, ADD, ADDSIZE)


#endif //STRBLDR_H