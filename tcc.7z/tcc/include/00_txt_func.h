#ifndef TXT_FUNC_H
#define TXT_FUNC_H

#ifdef UNICODE
#define fopen_rb(dir) _wfopen(dir,L"rt+,ccs=UTF-16LE")
#define fopen_wb(dir) _wfopen(dir,L"wt+,ccs=UTF-16LE")
#else
#define fopen_rb(dir) fopen(dir, "rb")
#define fopen_wb(dir) fopen(dir, "wb")
#endif

#include <00_err.h>

#ifndef SEEK_CUR
#define SEEK_CUR 1
#endif

#ifndef SEEK_END
#define SEEK_END 2
#endif

#ifndef SEEK_SET
#define SEEK_SET 0
#endif

#ifdef TBYTEARRAY
#define strz_t TCHAR*
void/*proc*/ FileToBytes(strz_t sPath, TByteArray* bFile)
{
    FILE* hFile = fopen_rb(sPath);
    if(!hFile)
    {
		printf("Error opening file");
		getch();
		exit(ERROR_FILE_OPEN);
	}

    fseek(hFile, 0, SEEK_END);
    (*bFile).size = ftell(hFile);
    fseek(hFile, 0, SEEK_SET);

    (*bFile).data = (typeof((*bFile).data)) malloc(sizeof(*(*bFile).data)*(*bFile).size);

    printf("Data Size %d\n\n", (*bFile).size);
	fread((*bFile).data, sizeof(*((*bFile).data)), (*bFile).size, hFile);
	fclose(hFile);
}

void/*proc*/ BytesToFile(TByteArray* bData, strz_t sPath)
{
    FILE* hFile = fopen_wb(sPath);
    printf("Length(*bData) = %d\n",Length(*bData));
    if(!hFile)
    {
		printf("Error opening file");
		getch();
		exit(ERROR_FILE_OPEN);
	}
	fwrite((*bData).data, sizeof(*(*bData).data), Length(*bData), hFile);
	fclose(hFile);
}
#endif

#define create_load_txt(NAME,DIR) \
    int      NAME##_size;\
    uint8_t* NAME;\
    char_t*  NAME##_in_dir = DIR;\
    FILE* NAME##_input = fopen_rb(NAME##_in_dir);\
    if(!NAME##_input)\
    {\
		wprintf(TEXT("Error opening file %s"), DIR); getch();\
		exit(ERROR_FILE_OPEN);\
	}\
    fseek(NAME##_input, 0, SEEK_END);\
    NAME##_size = ftell(NAME##_input);\
    fseek(NAME##_input, 0, SEEK_SET);\
    NAME = (typeof(NAME)) malloc(sizeof(*NAME)*NAME##_size+1);\
/*    printf("Data Size %d\n\n", NAME##_size);*/\
	fread(NAME, sizeof(*NAME), NAME##_size, NAME##_input); NAME[NAME##_size] = 0;\
	fclose(NAME##_input)

#define save_txt(NAME,SIZE,DIR) \
    char_t* NAME##_out_dir = DIR;\
    FILE*   NAME##_output = fopen_wb(NAME##_out_dir);\
    if(!NAME##_output)\
    {\
		printf(TEXT("Error opening file")); getch();\
		exit(ERROR_FILE_OPEN);\
	}\
    fwrite(NAME, SIZE, sizeof(*NAME), NAME##_output);\
	fclose(NAME##_output)


#endif //TXT_FUNC_H
