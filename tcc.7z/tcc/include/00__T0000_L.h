#define NULL    0
#define NULLPTR ((void *)0)

#define LOGIC_MIN 0
#define LOGIC_MAX 1
#define FALSE     LOGIC_MIN
#define TRUE      LOGIC_MAX
#define false FALSE
#define true  TRUE

#define INT8_MIN  0x80
#define INT16_MIN 0x8000
#define INT32_MIN 0x80000000
#define INT64_MIN 0x8000000000000000LL

#define INT8_MAX  0x7f
#define INT16_MAX 0x7fff
#define INT32_MAX 0x7fffffff
#define INT64_MAX 0x7fffffffffffffffLL


#define UINT8_MIN  0x0
#define UINT16_MIN 0x0000
#define UINT32_MIN 0x00000000
#define UINT64_MIN 0x0000000000000000ULL

#define UINT8_MAX  0xffU
#define UINT16_MAX 0xffffU
#define UINT32_MAX 0xffffffffU
#define UINT64_MAX 0xffffffffffffffffULL


#define SINT8_MIN  0x80
#define SINT16_MIN 0x8000
#define SINT32_MIN 0x80000000
#define SINT64_MIN 0x8000000000000000LL

#define SINT8_MAX  0x7f
#define SINT16_MAX 0x7fff
#define SINT32_MAX 0x7fffffff
#define SINT64_MAX 0x7fffffffffffffffLL

#define PTR_MIN    UINT64_MIN
#define PTR_MAX    UINT64_MAX
