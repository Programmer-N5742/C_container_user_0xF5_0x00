#ifndef MEM_FUNC_H
#define MEM_FUNC_H

#define MEM_A(NAME,CNT) NAME = (typeof(NAME))malloc(sizeof(*NAME)*(CNT))
#define MEM_F(NAME)     free(NAME)

//void*  memcpy8(void* dst, void* src, size_t size) {/*size >>= 0;*//*/=2*/for(uiter_t i = 0; i < size; ++i) (( uint8_t*)dst)[i] = (( uint8_t*)src)[i];}
void* memcpy16(void* dst, void* src, size_t size) {size >>= 1;    /*/=2*/for(uiter_t i = 0; i < size; ++i) ((uint16_t*)dst)[i] = ((uint16_t*)src)[i];}
void* memcpy32(void* dst, void* src, size_t size) {size >>= 2;    /*/=4*/for(uiter_t i = 0; i < size; ++i) ((uint32_t*)dst)[i] = ((uint32_t*)src)[i];}
void* memcpy64(void* dst, void* src, size_t size) {size >>= 3;    /*/=8*/for(uiter_t i = 0; i < size; ++i) ((uint64_t*)dst)[i] = ((uint64_t*)src)[i];}

void*  memcpy8(void* dst, const void* src, size_t n)
{
          uint8_t* dp = dst;
    const uint8_t* sp = src;
    while(n--) *dp++ = *sp++;
    return dst;
}

#endif //MEM_FUNC_H