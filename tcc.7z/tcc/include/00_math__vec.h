#ifndef MATH_VECTOR_H
#define MATH_VECTOR_H

#include <00_err.h>

#define vector_declare(type, name, ndim) Iterator name##_dim = ndim; type name
#define vector_create(name)              malloc(sizeof(*name) * name##_dim)
#define vector_destroy(name)             free(name);
#define vector_inicialize__n(name, n)    for(i, name##_dim) name[i] = n;     endfor(i)
#define vector_inicialize__arr(name, n)  for(i, name##_dim) name[i] = n[i];  endfor(i)
#define vector__Add(v0, v1)              for(i, v0##_dim)   v0[i]  += v1[i]; endfor(i)
#define vector__Sub(v0, v1)              for(i, v0##_dim)   v0[i]  -= v1[i]; endfor(i)
#define vector__Mul(v0, v1)              for(i, v0##_dim)   v0[i]  *= v1[i]; endfor(i)
#define vector__Div(v0, v1)              for(i, v0##_dim)   v0[i]  /= v1[i]; endfor(i)
#define vector__Rem(v0, v1)              for(i, v0##_dim)   v0[i]  %= v1[i]; endfor(i)
#define vector__Length(in_v, to_int)     for(i, v##_dim)    to_int += SQR(v[i]);        endfor(i) to_int = sqrt(to_int)
#define vector__Normalize(v)             Iterator v##_length; Length(v, v##_length) vector_Div(v, v##_length)
#define vector__Lerp(v0, v1, t, to_vec)  for(i, v0##_dim)   to_vec[i] = lerp(v0[i], v1[i], t) endfor(i)
#define vector__Distance(v0, v1, to_int) for(i, v0##_dim)   to_int += SQR(v1[i]-v0[i]); endfor(i) to_int = sqrt(to_int)




#define vector_construct__n(_name, _n) vector_create(_name); vector_inicialize__n(_name, _n);
#define vector_construct__arr(_name, _n) vector_create(_name); vector_inicialize__arr(_name, _n);
#define vector_destruct(_name) vector_destroy(_name)

#define vector_i__Scan(v) for(i, v##_dim) scanf(" %i", &v[i]); endfor(i)
#define vector_f__Scan(v) for(i, v##_dim) scanf(" %f", &v[i]); endfor(i)

#define vector_i__Print(v) for(i, v##_dim) printf(" %i", v[i]); endfor(i)
#define vector_f__Print(v) for(i, v##_dim) printf(" %f", v[i]); endfor(i)
#define endl printf("\n")

#define vector_ReadFile(v, dir)\
    FILE *input = NULL;\
	input = fopen(dir, "rb");\
	if(input == NULL)\
    {\
		printf("Error opening file");\
		getch();\
		exit(ERROR_FILE_OPEN);\
	}\
	fread(v, sizeof(*v), v##_dim, input);\
	fclose(input);

#define vector_WriteFile(v, dir)\
    FILE *output = NULL;\
	output = fopen(dir, "wb");\
	if(output == NULL)\
    {\
		printf("Error opening file");\
		getch();\
		exit(ERROR_FILE_OPEN);\
	}\
	fwrite(v, sizeof(*v), v##_dim, output);\
	fclose(output);

#ifdef _NS_VECTOR_
//���������� ����������� �����:
//{
#define v_decl(ztype, zname, zndim)    vector_declare(ztype,zname, zndim)
#define v_create(zname)                vector_create(zname)
#define v_dstr(zname)                  vector_destroy(zname)
#define v_incl__n(zname, zn)           vector_inicialize__n(zname, zn)
#define v_incl__arr(zname, zn)         vector_inicialize__arr(zname, zn)
#define v_Add(zv0, zv1)                vector__Add(zv0, zv1)
#define v_Sub(zv0, zv1)                vector__Sub(zv0, zv1)
#define v_Mul(zv0, zv1)                vector__Mul(zv0, zv1)
#define v_Div(zv0, zv1)                vector__Div(zv0, zv1)
#define v_Rem(zv0, zv1)                vector__Rem(zv0, zv1)
#define v_Length(z_in_v, z_to_int)     vector__Length(z_in_v, z_to_int)
#define v_Normalize(zv)                vector__Normalize(zv)
#define v_Lerp(zv0, zv1, zt, z_to_vec) vector__Lerp(zv0, zv1, zt, z_to_vec)
#define v_Distance(zv0, zv1, z_to_int) vector__Distance(zv0, zv1, z_to_int)

#define v_constr__n(z_name, z_n)     vector_construct__n(z_name, z_n)
#define v_constr__arr(z_name, z_n)   vector_construct__arr(z_name, z_n)
#define v_destr(z_name)              vector_destruct(z_name)

#define v_iScan(zv) vector_i__Scan(zv)
#define v_fScan(zv) vector_f__Scan(zv)

#define v_iPrint(zv) vector_i__Print(zv)
#define v_fPrint(zv) vector_f__Print(zv)

#define v_ReadF(zv, zdir)  vector_ReadFile(zv, zdir)
#define v_WriteF(zv, zdir) vector_WriteFile(zv, zdir)
//}

//��������� �����:
//{
#define v_new_n(nvec, nval)   vector_construct__n(nvec, nval)
#define v_new_arr(nvec, narr) vector_construct__arr(nvec, narr)
#define v_delete(nvec)        vector_destruct(nvec)
//}
#endif // _NS_VECTOR_


#endif //MATH_VECTOR_H