#define VOID  void
#define BOOL  uint8_t
#define BYTE  uint8_t
#define WORD  uint16_t
#define DWORD uint32_t
#define QWORD uint64_t

#define PVOID  VOID*
#define PBOOL  BOOL*
#define PBYTE  BYTE*
#define PWORD  WORD*
#define PDWORD DWORD*
#define PQWORD QWORD*

#define byte_t  uint8_t
#define word_t  uint16_t
#define dword_t uint32_t
#define qword_t uint64_t

#define BOOLEAN uint8_t
#define FALSE (0)
#define TRUE  (1)
#define false (0)
#define true  (1)

#define ATOM WORD