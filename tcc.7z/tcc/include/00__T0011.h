#define PROC      void
#define WNDPROC   void*
#define HANDLE    void*
#define HINSTANCE void*
#define HICON     void*
#define HCURSOR   void*
#define HBRUSH    void*
#define HWND      void*
#define HMENU     void*
#define LPVOID    void*
#define LPCSTR    CHAR*
#define NPSTR CHAR*
#define LPSTR CHAR*
#define PSTR  CHAR*
#define PTSTR   LPSTR
#define LPTSTR  LPSTR
#define PUTSTR  LPSTR
#define LPUTSTR LPSTR

#define UINT_PTR  UINT*
#define LONG_PTR  LONG*
#define PSIZE_T   SIZE_T*

#define WPARAM  UINT_PTR
#define LPARAM  LONG_PTR
#define LRESULT LONG_PTR

#define HANDLE  void*
#define HMODULE void*
#define THandle HANDLE
#define Boolean uint8_t
#define ULONG_PTR ULONG*
#define PTR_T   uint64_t
#define SIZE_T  uint64_t
#define UINT    uint32_t
#define WINBOOL   int
#define PWINBOOL  int*
#define LPWINBOOL int*

