#ifndef ERR_H
#define ERR_H

#define ERROR_NOT_FOUND -1
#define ERROR_FILE_OPEN -3

#define err_t uint8_t
err_t error = 0;

//START WinAPI errors
#ifndef errno_t
#define errno_t int
#define _ERRCODE_DEFINED
#endif

#ifndef _CRT_ERRNO_DEFINED
#define _CRT_ERRNO_DEFINED
  _CRTIMP extern int *__cdecl _errno(void);
#define errno (*_errno())

  errno_t __cdecl _set_errno(int _Value);
  errno_t __cdecl _get_errno(int *_Value);
#endif
//END WinAPI Errors

#endif //ERR_H
