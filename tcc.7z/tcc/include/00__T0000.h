#define void_t  void

#define uint8_t   unsigned char
#define uint16_t  unsigned short
#define uint32_t  unsigned int
#define uint64_t  unsigned long long
#define uint128_t struct {uint64_t l; uint64_t h;}

#define sint8_t   signed char
#define sint16_t  signed short
#define sint32_t  signed int
#define sint64_t  signed long long
#define sint128_t struct {uint64_t l; uint64_t h;}

#define char8_t   uint8_t
#define char16_t  uint16_t
#define char32_t  uint32_t
#define char64_t  uint64_t
#define char128_t uint128_t

#define str8_t   char8_t*
#define str16_t  char16_t*
#define str32_t  char32_t*
#define str64_t  char64_t*
#define str128_t char128_t*

#define float8_t   uint8_t
#define float16_t  uint16_t
#define float32_t  float
#define float64_t  double
#define float128_t struct {uint64_t l; uint64_t h;}

#define fixed8_t   uint8_t
#define fixed16_t  uint16_t
#define fixed32_t  uint32_t
#define fixed64_t  uint64_t
#define fixed128_t struct {uint64_t l; uint64_t h;}

#define logic_t    uint8_t

#define ptr_t      uint64_t



#define int8_t   sint8_t
#define int16_t  sint16_t
#define int32_t  sint32_t
#define int64_t  sint64_t
#define int128_t sint128_t

#define uiter_t uint64_t
#define siter_t sint64_t
#define iter_t  siter_t

#define cnt_t     uint64_t //count of elements
#define ord_t     sint64_t //order of element
#define size_t    uint64_t //bytesize of object
#define bitsize_t uint64_t //bitsize of object
#define len_t     uint64_t //length of strings
#define base_t    uint64_t //base of num sys
//#define char_t uint8_t
#ifdef T_TEST
#include <00_for_func.h>
#include <00_bit_func.h>
void test_types()
{
    printf("TEST uint8_t  START:\n");
    printf("sizeof(uint8_t) == %d bits;\n", bitsizeof(uint8_t ));
    printf("TEST uint8_t  %s\n", (bitsizeof(uint8_t) == 8)? "OK" : "ERROR");

    printf("TEST uint16_t START:\n");
    printf("sizeof(uint16_t) == %d bits;\n", bitsizeof(uint16_t));
    printf("TEST uint16_t %s\n", (bitsizeof(uint16_t) == 16)? "OK" : "ERROR");

    printf("TEST uint32_t START:\n");
    printf("sizeof(uint32_t) == %d bits;\n", bitsizeof(uint32_t));
    printf("TEST uint32_t %s\n", (bitsizeof(uint32_t) == 32)? "OK" : "ERROR");

    printf("TEST uint64_t START:\n");
    printf("sizeof(uint64_t) == %d bits;\n", bitsizeof(uint64_t));
    printf("TEST uint64_t %s\n", (bitsizeof(uint64_t) == 64)? "OK" : "ERROR");

    printf("TEST uint128_t START:\n");
    printf("sizeof(uint128_t) == %d bits;\n", bitsizeof(uint128_t));
    printf("TEST uint128_t %s\n", (bitsizeof(uint128_t) == 128)? "OK" : "ERROR");

    printf("\n");

    printf("TEST sint8_t  START:\n");
    printf("sizeof(sint8_t) == %d bits;\n", bitsizeof(sint8_t ));
    printf("TEST sint8_t  %s\n", (bitsizeof(sint8_t) == 8)? "OK" : "ERROR");

    printf("TEST sint16_t START:\n");
    printf("sizeof(sint16_t) == %d bits;\n", bitsizeof(sint16_t));
    printf("TEST sint16_t %s\n", (bitsizeof(sint16_t) == 16)? "OK" : "ERROR");

    printf("TEST sint32_t START:\n");
    printf("sizeof(sint32_t) == %d bits;\n", bitsizeof(sint32_t));
    printf("TEST sint32_t %s\n", (bitsizeof(sint32_t) == 32)? "OK" : "ERROR");

    printf("TEST sint64_t START:\n");
    printf("sizeof(sint64_t) == %d bits;\n", bitsizeof(sint64_t));
    printf("TEST sint64_t %s\n", (bitsizeof(sint64_t) == 64)? "OK" : "ERROR");

    printf("TEST sint128_t START:\n");
    printf("sizeof(sint128_t) == %d bits;\n", bitsizeof(sint128_t));
    printf("TEST sint128_t %s\n", (bitsizeof(sint128_t) == 128)? "OK" : "ERROR");


    printf("\n");

    printf("TEST float8_t  START:\n");
    printf("sizeof(float8_t) == %d bits;\n", bitsizeof(float8_t ));
    printf("TEST float8_t  %s\n", (bitsizeof(float8_t) ==  8)? "OK" : "ERROR");

    printf("TEST float16_t START:\n");
    printf("sizeof(float16_t) == %d bits;\n", bitsizeof(float16_t));
    printf("TEST float16_t %s\n", (bitsizeof(float16_t) == 16)? "OK" : "ERROR");

    printf("TEST float32_t START:\n");
    printf("sizeof(float32_t) == %d bits;\n", bitsizeof(float32_t));
    printf("TEST float32_t %s\n", (bitsizeof(float32_t) == 32)? "OK" : "ERROR");

    printf("TEST float64_t START:\n");
    printf("sizeof(float64_t) == %d bits;\n", bitsizeof(float64_t));
    printf("TEST float64_t %s\n", (bitsizeof(float64_t) == 64)? "OK" : "ERROR");

    printf("TEST float128_t START:\n");
    printf("sizeof(float128_t) == %d bits;\n", bitsizeof(float128_t));
    printf("TEST float128_t %s\n", (bitsizeof(float128_t) == 128)? "OK" : "ERROR");


    printf("\n");

    printf("TEST fixed8_t  START:\n");
    printf("sizeof(fixed8_t) == %d bits;\n", bitsizeof(fixed8_t ));
    printf("TEST fixed8_t  %s\n", (bitsizeof(fixed8_t) == 8)? "OK" : "ERROR");

    printf("TEST fixed16_t START:\n");
    printf("sizeof(fixed16_t) == %d bits;\n", bitsizeof(fixed16_t));
    printf("TEST fixed16_t %s\n", (bitsizeof(fixed16_t) == 16)? "OK" : "ERROR");

    printf("TEST fixed32_t START:\n");
    printf("sizeof(fixed32_t) == %d bits;\n", bitsizeof(fixed32_t));
    printf("TEST fixed32_t %s\n", (bitsizeof(fixed32_t) == 32)? "OK" : "ERROR");

    printf("TEST fixed64_t START:\n");
    printf("sizeof(fixed64_t) == %d bits;\n", bitsizeof(fixed64_t));
    printf("TEST fixed64_t %s\n", (bitsizeof(fixed64_t) == 64)? "OK" : "ERROR");

    printf("TEST fixed128_t START:\n");
    printf("sizeof(fixed128_t) == %d bits;\n", bitsizeof(fixed128_t));
    printf("TEST fixed128_t %s\n", (bitsizeof(fixed128_t) == 128)? "OK" : "ERROR");

    printf("\n");
}
#endif
