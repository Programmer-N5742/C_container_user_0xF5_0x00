#ifndef FLBIT_FUNC_H
#define FLBIT_FUNC_H

uint32_t getHighBit_32(uint32_t x)
{
    x |= x >> 1;
    x |= x >> 2;
    x |= x >> 4;
    x |= x >> 8;
    x |= x >> 16;
    return x - (x >> 1);
}
uint32_t getBitCount_32(uint32_t x)
{
	x = (x & 0x55555555) + ((x >> 1) & 0x55555555);
	x = (x & 0x33333333) + ((x >> 2) & 0x33333333);
	x = (x & 0x0F0F0F0F) + ((x >> 4) & 0x0F0F0F0F);
	x = (x & 0x00FF00FF) + ((x >> 8) & 0x00FF00FF);
	return (x & 0x0000FFFF) + (x >> 16);
}
uint32_t getLog2_32(uint32_t x)
{
    if(x==0) return 0;
    return getBitCount_32(getHighBit_32(x) - 1);
}


#define FL32__GET_SIGN(x) ((uint8_t) ((x&0b10000000000000000000000000000000)>>31))
#define FL32__GET_EXP(x)  ((uint8_t) ((x&0b01111111100000000000000000000000)>>23))
#define FL32__GET_FRAC(x) ((uint32_t)((x&0b00000000011111111111111111111111)>>0 ))

//SET ONLY IF ALL TO ZEROES
#define ZFL32__SET_SIGN(x,n) x = (x|(n&0b00000000000000000000000000000001)<<31)
#define ZFL32__SET_EXP(x,n)  x = (x|(n&0b00000000000000000000000011111111)<<23)
#define ZFL32__SET_FRAC(x,n) x = (x|(n&0b00000000011111111111111111111111)<<0 )

//SET ALREADY
#define FL32__SET_SIGN(x,n) {BIT_SET0_FROM_TO(x,31,1); ZFL32__SET_SIGN(x,n);}
#define FL32__SET_EXP(x,n)  {BIT_SET0_FROM_TO(x,23,8); ZFL32__SET_FRAC(x,n);}
#define FL32__SET_FRAC(x,n) {BIT_SET0_FROM_TO(x,0,23); ZFL32__SET_FRAC(x,n);}
#define FL32__SET_ALL(x,sign1,exp8,frac23) {x = 0; ZFL32__SET_SIGN(x,sign1); ZFL32__SET_EXP(x,exp8); ZFL32__SET_FRAC(x,frac23);}

typedef union
{
    float32_t f;
    uint32_t i;
} fl32;//1,8,23

#define FL_32__MIN \
0b0\
00000001\
00000000000000000000000

#define FL_32__MAX \
0b0\
11111110\
11111111111111111111111



#define FL64__GET_SIGN(x) ((uint8_t )((x&0b10000000000000000000000000000000\
00000000000000000000000000000000)>>63))
#define FL64__GET_EXP(x)  ((uint16_t)((x&0b01111111111100000000000000000000\
00000000000000000000000000000000)>>52))
#define FL64__GET_FRAC(x) ((uint64_t)((x&0b00000000000011111111111111111111\
11111111111111111111111111111111)>>0))
typedef union
{
    float64_t f;
    uint64_t i;
} fl64;//1,11,52
//1,15,112

#define FL_64__SET_SIGN0(x) (BIT_SET_0(x,63))
#define FL_64__SET_SIGN1(x) (BIT_SET_1(x,39))
//#define FL_64__SET_SIGN2(num,x,n) (num ^= (-x ^ num) & (1LL << n))
#define FL_64__SET_SIGN2(x,n,state) (BIT_SET(x,n,state))

#define FL_64__MIN \
0b0\
00000000000\
0000000000000000000000000000000000000000000000000001

#define FL_64__MAX \
0b0\
11111111110\
1111111111111111111111111111111111111111111111111111

#define def_get_cnt_1bits(T) \
uint8_t get_cnt_1bits##T(uint##T##_t x)\
{\
    uint8_t bits = 0;\
    while(x) {bits += x & 1LL; x >>= 1LL;}\
    return bits;\
}\
uint8_t get_cnt_1bfast##T(uint##T##_t x)\
{\
    uint8_t bits = 0;\
    while(x) {x &= x - 1; ++bits;}\
}
def_get_cnt_1bits(32) def_get_cnt_1bits(64)



#define to_type(THIS,TO_TYPE) (*((TO_TYPE*)&THIS))
float32_t float32_t__construct(uint32_t sign, uint32_t exp, uint32_t frac)
{
    float32_t r; //to_type(r,uint32_t) = 0;
    sign &= 0b00000000000000000000000000000001;
    exp += 127; exp &= 0b00000000000000000000000011111111;
    frac &= 0b00000000111111111111111111111111;
    uint8_t frac_size = getLog2_32(frac);
    BIT_SET0_FROM_TO(frac,frac_size,1); --frac_size;
    /*printf("sign = %s;\n", getbinstr32(sign));
    printf("exp  = %s;\n", getbinstr32(exp ));
    printf("frac = %s;\n", getbinstr32(frac));*/
    to_type(r,uint32_t) = (sign<<31) + ((exp)<<23) + (frac<<(22-frac_size));
    return r;
}


#endif //FLBIT_FUNC_H