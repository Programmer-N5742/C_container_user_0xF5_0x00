//SOURCE: https://cppprosto.blogspot.com/2017/09/blog-post_20.html?m=1

//call bf_free() after all get...str##///TYPE///(num) functions
#ifndef BIT_FUNC_H
#define BIT_FUNC_H

#define BITS_IN_BYTE 8
#define bitsizeof(n) (sizeof(n)*(BITS_IN_BYTE))

#define BIT_ABS_STATIC_prepare_mask(v) typeof((v)) BIT_ABS_STATIC_temp_mask##__COUNTER__ = BIT_ABS_temp_mask(v); 
#define BIT_ABS_STATIC0(v) (((v) + BIT_ABS_STATIC_temp_mask##(__COUNTER__-1)) ^ BIT_ABS_STATIC_temp_mask##(__COUNTER__-1))
#define BIT_ABS_STATIC1(v) (((v) ^ BIT_ABS_STATIC_temp_mask##(__COUNTER__-1)) - BIT_ABS_STATIC_temp_mask##(__COUNTER__-1))
#define BIT_ABS_DYNAMIC0(v) (((v) + BIT_ABS_temp_mask((v))) ^ BIT_ABS_temp_mask((v)))
#define BIT_ABS_DYNAMIC1(v) (((v) ^ BIT_ABS_temp_mask((v))) - BIT_ABS_temp_mask((v)))

#define BIT_ABS_STATIC(v)  (BIT_ABS_STATIC0((v)))
#define BIT_ABS_DYNAMIC(v) (BIT_ABS_DYNAMIC0((v)))
#define BIT_ABS(v)         (BIT_ABS_DYNAMIC((v)))

#define BIT_MIN(a,b) ((b) ^ (((a) ^ (b)) & -((a) < (b))))
#define BIT_MAX(a,b) ((a) ^ (((a) ^ (b)) & -((a) < (b))))

//Merge bits from two values according to a mask: 0 - a; 1 - b
#define BIT_MERGE_VAR_AS_BITS0(a,b,mask) ((a) ^ (((a) ^ (b)) & (mask)))
#define BIT_MERGE_VAR_AS_BITS1(a,b,mask) ((a) & ~(mask)) | ((b) & (mask))


//SET TO ZEROES FROM [nstart] bit with [nsize] length
#define BIT_SET0_FROM_TO(x,nstart,nsize) (x) & (~(((1LL<<(nsize))-1LL)<<(nstart)))

char alphabeta[16] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
#define alphabetafunc(n) (alphabeta[(n)])
//#define res bf_res
char* bfres;
#define cnt uint8_t
#define def_getbinstr(BITS)\
char* getbinstr##BITS(uint##BITS##_t n)\
{\
    cnt bfres_cnt = bitsizeof(n);\
    bfres = (typeof(bfres)) malloc(sizeof(*bfres)*(bfres_cnt+1));\
    FOR(i,bfres_cnt) bfres[bfres_cnt-i-1] = alphabetafunc(((n>>i) & 0b1));\
    bfres[bfres_cnt] = 0;\
    return bfres;\
}
def_getbinstr(8) def_getbinstr(16) def_getbinstr(32) def_getbinstr(64)


#define def_getquadstr(BITS)\
char* getquadstr##BITS(uint##BITS##_t n)\
{\
    cnt bfres_cnt = bitsizeof(n)>>1;\
    bfres = (typeof(bfres)) malloc(sizeof(*bfres)*bfres_cnt+1);\
    FOR(i,bfres_cnt) bfres[bfres_cnt-i-1] = alphabetafunc(((n>>(i<<1)) & 0b11));\
    bfres[bfres_cnt] = 0;\
    return bfres;\
}
def_getquadstr(8) def_getquadstr(16) def_getquadstr(32) def_getquadstr(64)

#define def_gethexstr(BITS)\
char* gethexstr##BITS(uint##BITS##_t n)\
{\
    cnt bfres_cnt = bitsizeof(n)>>2;\
    bfres = (typeof(bfres)) malloc(sizeof(*bfres)*bfres_cnt+1);\
    FOR(i,bfres_cnt) bfres[bfres_cnt-i-1] = alphabetafunc(((n>>(i<<2)) & 0b1111));\
    bfres[bfres_cnt] = 0;\
    return bfres;\
}
def_gethexstr(8) def_gethexstr(16) def_gethexstr(32) def_gethexstr(64)




#define g2ps_h(n) ((0b1<<(n))-1)     //write ones
#define g2ps_n(n) (g2ps_h((1<<(n)))) //write (n==0)?1:(n==1)?2:(n==2)?4 //((n==0)? g2ps_h(1) : (n==1)? g2ps_h(2) : /*(n==2)?*/ g2ps_h(4))
#define def_get2powstr(BITS,POWof2)\
char* get2pow##POWof2##str##BITS(uint##BITS##_t n)\
{\
    cnt bfres_cnt = bitsizeof(n)>>POWof2;\
    bfres = (typeof(bfres)) malloc(sizeof(*bfres)*bfres_cnt+1);\
    FOR(i,bfres_cnt) bfres[bfres_cnt-i-1] = alphabetafunc(((n>>(i<<POWof2)) & (g2ps_n(POWof2))));\
    bfres[bfres_cnt] = 0;\
    return bfres;\
}
def_get2powstr(8,0) def_get2powstr(16,0) def_get2powstr(32,0) def_get2powstr(64,0)
def_get2powstr(8,1) def_get2powstr(16,1) def_get2powstr(32,1) def_get2powstr(64,1)
def_get2powstr(8,2) def_get2powstr(16,2) def_get2powstr(32,2) def_get2powstr(64,2)


#define bf_free() free(bfres)
//#undef res

#define BIT_SET_0(x,n)     ((x) & ~(1LL<<(n)))
#define BIT_SET_1(x,n)     ((x) |  (1LL<<(n)))
#define BIT_SET_2(x,n)     ((x) ^  (1LL<<(n)))
#define BIT_SET(x,n,s)     (((v) & ~(1LL<<(n))) | (-(s) & (1LL<<(n))))
#define BIT_SETv0(x,n,state) ((state)? ((x) | (1LL<<(n))) : ((x) & ~(1LL<<(n))))
#define BIT_SETv1(x,n,state) ((x) ^ (-(state) ^ (x)) & (1LL << (n)))
#define BIT_SET_PRECOMPILE(x,n,state) (BIT_SET_##state((x),(n)))

#define ELEM_SET_0(x) ((x)=(      ((typeof((x)))(0) )))
#define ELEM_SET_1(x) ((x)=(     ~((typeof((x)))(0) )))
#define ELEM_SET_2(x) ((x)=((x) ^ ((typeof((x)))(0) )))
#define ELEM_SET(x,n,state) ((x) = (state)? (     ~(( typeof((x)))(0) )) : (      (( typeof((x)))(0) )))
#define ELEM_SET_PRECOMPILE(x,state) (ELEM_SET_##state((n),(state)))

#define ARR_SET_0(x,len) FOR(i,(len)) ELEM_SET_0(x[i])
#define ARR_SET_1(x,len) FOR(i,(len)) ELEM_SET_1(x[i])
#define ARR_SET_2(x,len) FOR(i,(len)) ELEM_SET_2(x[i])
#define ARR_SET(x,state) if((state)) ARR_SET_1((x),(len)) else ARR_SET_0((x),(len))
#define ARR_SET_PRECOMPILE(x,len,state) (ARR_SET_##state((x),(len)))

#define IS_EVEN(n) ( (n) & (1))
#define IS_ODD(n)  ((~n) & (1))

#define BIT_SWAP_XOR_OTHERS0(a, b)     {a = a ^ b;   b = b ^ a;   a = a ^ b;}
#define BIT_SWAP_XOR_OTHERS1(a, b)     (((a) ^= (b)), ((b) ^= (a)), ((a) ^= (b)))
#define BIT_SWAP_XOR(a, b)            (((a) == (b)) || (((a) ^= (b)), ((b) ^= (a)), ((a) ^= (b))))
#define BIT_SWAP_XOR_MAY_FASTER(a, b) (((a)  ^ (b)) && ((b) ^= (a) ^= (b), (a) ^= (b)))

//i, j; // positions of bit sequences to swap
//n;    // number of consecutive bits in each sequence
//b;    // bits to swap reside in b
//r;    // result
#define BIT_SWAP_BITS_tempXOR(i,j,n,b) ((b >> i) ^ (b >> j)) & ((1U << n) - 1); // XOR temporary
#define BIT_SWAP_BITS(i,j,n,b)         (b ^ ((BIT_SWAP_BITS_tempXOR((i),(j),(n),(b)) << (i)) | (BIT_SWAP_BITS_tempXOR((i),(j),(n),(b)) << (j))));

#define def_bit_swap_bits(BITS) \
uint8_t bit_swap_bits##BITS(uint##BITS##_t* a, uint##BITS##_t* b, uint8_t n, uint8_t i, uint8_t j)\
{\
    uint8_t x = ((*b >> i) ^ (*b >> j)) & ((1ULL << n) - 1LL);/*XOR temporary*/\
    return *b ^ ((x << i) | (x << j));\
}
def_bit_swap_bits(8) def_bit_swap_bits(16) def_bit_swap_bits(32) def_bit_swap_bits(64)

//Compute modulus division by 1 << s without a division operator
#define BIT_REM_2POWn(a,b)  ((n) & ((1ULL << (b)) - 1LL)) //REMorMOD? negative numbers?

#define BIT_GET(x,n) (((x)>>(n)) & 1LL)
#define BIT_GET_ON_PLACE(x,n) (((n) & (1LL << (x))))

#define BIT_MUL_2POWn(x,n) ((x) << (n))
#define BIT_DIV_2POWn(x,n) ((x) >> (n))

//BIT_isPow_2_v0
#define BIT_IS_2POW_v0(x)        (((x) != 0) && (((x) & (~(x) + 1LL)) == (x)))
#define BIT_IS_2POW_v1(x)        (((x) != 0) && (((x) & ((x) - 1LL)) == 0))
#define BIT_IS_2POW_v2(x)        (!((x) & ((x) - 1LL)) && (x))
#define BIT_IS_2POW_v3(x)        ((x) && !((x) & ((x) - 1LL)))
#define BIT_IS_2POW_v4(x)           (        ((v) & ((v) - 1LL)) == 0)
#define BIT_IS_2POW_WITHOUT_0(x) ((v) && !((v) & ((v) - 1LL)))


#define GET_CNT_IN_NUMSYS(base,x) (log_((base),(x)))
#undef cnt

#endif //BIT_FUNC_H
