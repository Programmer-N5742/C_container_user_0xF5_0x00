#ifndef STDIO_FUNC_H
#define STDIO_FUNC_H

#include <00_var_types.h>
#include <00_call_conv.h>

#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2

/* Returned by various functions on end of file condition or error. */
#define	EOF	(-1)

#ifndef _FILE_DEFINED
typedef struct _iobuf
{
    int8_t* _ptr;
    int32_t _cnt;
    int8_t* _base;
    int32_t _flag;
    int32_t _file;
    int32_t _charbuf;
    int32_t _bufsiz;
    int8_t* _tmpfname;
} FILE;
#define _FILE_DEFINED
#endif

__cdecl int32_t puts(const int8_t* str);
__cdecl int32_t printf(const int8_t* _Format,...);

#ifndef WINUSERAPI
#ifdef __W32API_USE_DLLIMPORT__
#define WINUSERAPI DECLSPEC_IMPORT
#else
#define WINUSERAPI
#endif
#endif
WINUSERAPI short WINAPI GetAsyncKeyState(int32_t);



FILE *__cdecl fopen(const int8_t *_Filename,const int8_t *_Mode);
int32_t __cdecl fseek(FILE *_File,int32_t _Offset,int32_t _Origin);
long __cdecl ftell(FILE *_File);
#define size_t uint64_t
size_t __cdecl fread(void *_DstBuf,size_t _ElementSize,size_t _Count,FILE *_File);

#endif //STDIO_FUNC_H
