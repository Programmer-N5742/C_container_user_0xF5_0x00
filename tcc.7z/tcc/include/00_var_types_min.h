#ifndef VAR_TYPES_MIN_H
#define VAR_TYPES_MIN_H

#define b_t   unsigned char
#define b1_t  unsigned char
#define b2_t  unsigned short
#define b4_t  unsigned long
#define b8_t  unsigned long long

#define ub_t  unsigned char
#define ub1_t unsigned char
#define ub2_t unsigned short
#define ub4_t unsigned long
#define ub8_t unsigned long long

#define sb_t  signed char
#define sb1_t signed char
#define sb2_t signed short
#define sb4_t signed long
#define sb8_t signed long long

#endif //VAR_TYPES_MIN_H
