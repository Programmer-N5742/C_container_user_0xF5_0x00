#ifndef LOGIC_FUNC_H
#define LOGIC_FUNC_H

//typedef uint8_t logic_t;

#define n(a,b,n00,n01,n10,n11) ((a == 0 && b == 0)? n00: \
                                (a == 0 && b == 1)? n01: \
                                (a == 1 && b == 0)? n10: \
                                /*(a == 1 && b == 1)?*/ n11)
//1000
#define bit(a,b,n) ((a & 0) & (b & 0))? : ((n>>0b00) && 0)\
                    (a & 0) & (b & 0))? : ((n>>0b01) && 0)\
                    (a & 0) & (b & 0))? : ((n>>0b10) && 0)\
                    (a & 0) & (b & 0))? : ((n>>0b11) && 0)\

logic_t n0000(logic_t a, logic_t b){return n(a,b,0,0,0,0);}
logic_t n0001(logic_t a, logic_t b){return n(a,b,0,0,0,1);}
logic_t n0010(logic_t a, logic_t b){return n(a,b,0,0,1,0);}
logic_t n0011(logic_t a, logic_t b){return n(a,b,0,0,1,1);}
logic_t n0100(logic_t a, logic_t b){return n(a,b,0,1,0,0);}
logic_t n0101(logic_t a, logic_t b){return n(a,b,0,1,0,1);}
logic_t n0110(logic_t a, logic_t b){return n(a,b,0,1,1,0);}
logic_t n0111(logic_t a, logic_t b){return n(a,b,0,1,1,1);}
logic_t n1000(logic_t a, logic_t b){return n(a,b,1,0,0,0);}
logic_t n1001(logic_t a, logic_t b){return n(a,b,1,0,0,1);}
logic_t n1010(logic_t a, logic_t b){return n(a,b,1,0,1,0);}
logic_t n1011(logic_t a, logic_t b){return n(a,b,1,0,1,1);}
logic_t n1100(logic_t a, logic_t b){return n(a,b,1,1,0,0);}
logic_t n1101(logic_t a, logic_t b){return n(a,b,1,1,0,1);}
logic_t n1110(logic_t a, logic_t b){return n(a,b,1,1,1,0);}
logic_t n1111(logic_t a, logic_t b){return n(a,b,1,1,1,1);}

#endif //LOGIC_FUNC_H
