#ifndef SYS_FUNC_H
#define SYS_FUNC_H

#include <00_stdio.h>
#include <00_var_types.h>
#include <00_mem_func.h>
#include <00_call_conv.h>
#include <00_for_func.h>

#ifndef WINUSERAPI
#ifdef __W32API_USE_DLLIMPORT__
#define WINUSERAPI DECLSPEC_IMPORT
#else
#define WINUSERAPI
#endif
#endif
WINUSERAPI SHORT WINAPI GetAsyncKeyState(int);

#ifndef DECL_IMPORT
#define DECL_IMPORT __declspec(dllimport)
#endif

#ifndef DECL_EXPORT
#define DECL_EXPORT __declspec(dllexport)
#endif

#if defined(_NTOSKRNL_)
#ifndef NTOSAPI
#define NTOSAPI DECL_EXPORT
#endif
#define DECLARE_INTERNAL_OBJECT(x) typedef struct _##x; typedef struct _##x *P##x;
#define DECLARE_INTERNAL_OBJECT2(x,y) typedef struct _##x; typedef struct _##x *P##y;
#else
#ifndef NTOSAPI
#define NTOSAPI DECL_IMPORT
#endif
#define DECLARE_INTERNAL_OBJECT(x) struct _##x; typedef struct _##x *P##x;
#define DECLARE_INTERNAL_OBJECT2(x,y) struct _##x; typedef struct _##x *P##y;
#endif

#if !defined(NTSTATUS)
typedef LONG NTSTATUS;
typedef NTSTATUS *PNTSTATUS;
#endif

typedef union _LARGE_INTEGER {
  struct {
    DWORD LowPart;
    LONG  HighPart;
  } DUMMYSTRUCTNAME;
  struct {
    DWORD LowPart;
    LONG  HighPart;
  } u;
  LONGLONG QuadPart;
} LARGE_INTEGER;
typedef LARGE_INTEGER *PLARGE_INTEGER;

#define TIME LARGE_INTEGER
#define _TIME _LARGE_INTEGER
#define PTIME PLARGE_INTEGER
#define LowTime LowPart
#define HighTime HighPart

NTOSAPI
NTSTATUS
NTAPI
ZwDelayExecution(
  /*IN*/ BOOLEAN  Alertable,
  /*IN*/ PLARGE_INTEGER  Interval);
LARGE_INTEGER Interval;
#define Sleep(SleepTime) \
/*Interval.u.LowPart = 5000;*/\
/*Interval.u.HighPart = 0xFFFFFFFF;*/\
Interval.QuadPart = -SleepTime * 1000 * 10;\
ZwDelayExecution(FALSE, &Interval)
//Interval.u.LowPart = 0xFF676980;\
//Interval.u.HighPart = 0xFFFFFFFF;
WINBASEAPI HANDLE WINAPI GetCurrentProcess(void);

WINBASEAPI WINBOOL WINAPI TerminateProcess(HANDLE hProcess,UINT uExitCode);


NTOSAPI
NTSTATUS
NTAPI
NtTerminateProcess(
  /*IN*/ HANDLE  ProcessHandle  /*OPTIONAL*/,
  /*IN*/ NTSTATUS  ExitStatus);

NTOSAPI
NTSTATUS
NTAPI
ZwTerminateProcess(
  /*IN*/ HANDLE  ProcessHandle  /*OPTIONAL*/,
  /*IN*/ NTSTATUS  ExitStatus);

#endif //SYS_FUNC_H