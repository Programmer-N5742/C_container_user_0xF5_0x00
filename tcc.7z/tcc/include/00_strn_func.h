#ifndef STRN_FUNC_H
#define STRN_FUNC_H






#endif //STRN_FUNC_H
