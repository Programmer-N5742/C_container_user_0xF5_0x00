#ifndef VAR_TYPES_H
#define VAR_TYPES_H

#include <00_var_types_min.h>

#define symb_t b_t
#define strz_t symb_t*
#define str_t  strz_t

#define logic_t   b_t
#define variant_t b_t

#define iter_t sb8_t

#define symb symb_t

#define _8   signed char
#define _16  short
#define _32  int
#define _64  long long

#define _u8  unsigned char
#define _u16 unsigned short
#define _u32 unsigned
#define _u64 unsigned long long




#define logic_t uint8_t

#include <00__T0000.h> //([SIGN])#[TYPE]#[BITS]#"_t"
#include <00__T0000_L.h>
#include <00__T0001.h> //MSDOS
#include <00__T0001_L.h>
#include <00__T0010.h> //C
#include <00__T0010_L.h>
#include <00__T0011.h> //WINAPI
#include <00__T0011_L.h>


#define function(RETTYPE) RETTYPE
#define func(RETTYPE)     function(RETTYPE)

#define procedure void
#define proc procedure



#define byte    uint8_t




#define cnt8  uint8_t
#define cnt16 uint16_t
#define cnt32 uint32_t
#define cnt64 uint64_t

#define ord8  sint8_t
#define ord16 sint16_t
#define ord32 sint32_t
#define ord64 sint64_t

#define INT_MAX SINT32_MAX





#define ptr_t  uint64_t
#define size_t uint64_t
#define cnt_t cnt32
#define ord_t ord32
#define cnt cnt32
#define ord ord32
#define iter_t uint32_t

typedef struct TByteArray_s
{
    cnt_t size;
    BYTE* data;
} TByteArray;

#define GetByteArrayLength(x) ((x).size)
#define SetByteArrayLength(BYTEARR, SIZE) BYTEARR.size = SIZE; BYTEARR.data = (BYTE*) realloc(BYTEARR.data, BYTEARR.size);//(BYTEARR.data) = realloc(*(BYTEARR.data),(SIZE))


#define strN TByteArray
#define strZ char*
#define strn TByteArray
#define strz char*
#define string char*


#define CONST const



#ifndef _NO_W32_PSEUDO_MODIFIERS
#define IN
#define OUT
#define OPTIONAL
#define UNALLIGNED

#define _In_
#define _Out_
#define _Optional_
#define _Unalligned_
#endif

/*
typedef signed char INT8,*PINT8;
  typedef signed short INT16,*PINT16;
  typedef signed int INT32,*PINT32;
  typedef signed __int64 INT64,*PINT64;
  typedef unsigned char UINT8,*PUINT8;
  typedef unsigned short UINT16,*PUINT16;
  typedef unsigned int UINT32,*PUINT32;
  typedef unsigned __int64 UINT64,*PUINT64;
  typedef signed int LONG32,*PLONG32;
  typedef unsigned int ULONG32,*PULONG32;
  typedef unsigned int DWORD32,*PDWORD32;
*/






#endif //VAR_TYPES_H
