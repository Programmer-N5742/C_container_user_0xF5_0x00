#ifndef IMG_H
#define IMG_H

#include <00_call_conv.h>
#include <00_stdio.h>
#define STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include <07_img_load.h>
#include <07_img_write.h>

#define img_create(name,width,height,cnt) \
int name##_w=width; int name##_h=height; int name##_c=cnt;\
uint8_t* name##_d = (uint8_t*)malloc(sizeof(uint8_t) * name##_w*name##_h*name##_c);

#define img_create_load(name,dir) \
int name##_w, name##_h, name##_c;\
uint8_t* name##_d = stbi_load(dir, &name##_w, &name##_h, &name##_c, 0);

#define img_copy(from,to) \
FOR(y,MIN(from##_h,to##_h)) FOR(x,MIN(from##_w,to##_w))\
{\
    to##_d[(y*to##_w+x)*to##_c+0] = from##_d[(y*to##_w+x)*to##_c+0];\
    to##_d[(y*to##_w+x)*to##_c+1] = from##_d[(y*to##_w+x)*to##_c+1];\
    to##_d[(y*to##_w+x)*to##_c+2] = from##_d[(y*to##_w+x)*to##_c+2];\
}

#define img_save(name,dir) \
stbi_write_bmp(dir,name##_w,name##_h,name##_c,(void*)name##_d);

#define img_free(name) \
stbi_image_free(name##_d);

#endif //IMG_H