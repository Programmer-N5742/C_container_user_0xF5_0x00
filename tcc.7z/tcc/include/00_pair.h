#ifndef PAIR_H
#define PAIR_H

typedef struct 
{
    T1 first;
    T2 second;
} zpair;

void zpair_construct(struct zpair* p, T1 a, T2 b)
{
    (*p).first  = a;
    (*p).second = b;
}

zpair zmake_pair(T1 a, T2 b)
{
    return zpair(a,b);
}

#endif //PAIR_H
