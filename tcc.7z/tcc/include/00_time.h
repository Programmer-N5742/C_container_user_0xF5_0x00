#ifndef ZTIME_H
#define ZTIME_H

#include <time.h>


#define time_def \
real iTime;\
real iTime_start;

#define time_start \
iTime = 0.0f;\
iTime_start = ((real)clock());

#define time_def_start \
real iTime = 0.0f;\
real iTime_start = clock();

#define time_end \
iTime = (((real)clock()) - iTime_start);

#define time_endprint \
printf("time=%0.19lf\n", (((real)clock()) - iTime_start));

#define time_end_print \
iTime = (((real)clock()) - iTime_start);\
printf("time=%0.19lf\n", iTime);



#define midtime_def \
uint64_t midtime_size;\
real iTime;\
real iTime_start;

#define midtime_start(SIZE) \
midtime_size = SIZE;\
iTime = 0.0f;\
iTime_start = ((real)clock());

#define midtime_def_start(SIZE) \
uint64_t midtime_size = SIZE;\
real iTime = 0.0f;\
real iTime_start = clock();

#define midtime_get ((((real)clock()) - iTime_start)/midtime_size)

#define midtime_end \
iTime = (((real)clock()) - iTime_start)/midtime_size;

#define midtime_print \
printf("time=%0.19lf\n", (((real)clock()) - iTime_start) / ((real)midtime_size));


#define midtime_end_print \
iTime = (((real)clock()) - iTime_start)/midtime_size;\
printf("time=%0.19lf\n", iTime);



#endif //ZTIME_H
