#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <locale.h>
#include <conio.h>
#include <windows.h>
#include <00_var_types.h>
#include <00_for_func.h>
#include <00_call_conv.h>
#include <00_mem_func.h>
#include <00_main_terms.h>
#include <00_math.h>


#define BITS_IN_BYTE 8
#define bitsizeof(n) ((BITS_IN_BYTE) * (sizeof((n))))
#define bso(n)       (bitsizeof(n))
#define struct_func inline

#define ma malloc
#define mf free
#define so sizeof
#define to typeof
#define decltype typeof

#define itr _u32

#define print printf
#define scan  scanf

#define __   return

#define logic_t uint8_t
#define variant_t uint8_t
#define cnt  uint32_t
#define ord  int32_t
#define real double
#define symb char

#endif //MAIN_H