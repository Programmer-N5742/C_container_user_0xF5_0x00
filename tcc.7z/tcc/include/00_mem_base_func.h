#ifndef MEM_BASE_FUNC_H
#define MEM_BASE_FUNC_H

#include <00_var_types.h>
#include <00_call_conv.h>

//from winbase.h
#ifndef WINBASEAPI
#ifdef __W32API_USE_DLLIMPORT__
#define WINBASEAPI DECLSPEC_IMPORT
#else
#define WINBASEAPI
#endif
#endif
WINBASEAPI PVOID WINAPI VirtualAlloc(PVOID,DWORD,DWORD,DWORD);
WINBASEAPI PVOID WINAPI VirtualAllocEx(HANDLE,PVOID,DWORD,DWORD,DWORD);
WINBASEAPI BOOL WINAPI VirtualFree(PVOID,DWORD,DWORD);
WINBASEAPI BOOL WINAPI VirtualFreeEx(HANDLE,PVOID,DWORD,DWORD);
WINBASEAPI BOOL WINAPI VirtualLock(PVOID,DWORD);
WINBASEAPI BOOL WINAPI VirtualProtect(PVOID,DWORD,DWORD,PDWORD);
WINBASEAPI BOOL WINAPI VirtualProtectEx(HANDLE,PVOID,DWORD,DWORD,PDWORD);
//WINBASEAPI DWORD WINAPI VirtualQuery(LPCVOID,PMEMORY_BASIC_INFORMATION,DWORD);
//WINBASEAPI DWORD WINAPI VirtualQueryEx(HANDLE,LPCVOID,PMEMORY_BASIC_INFORMATION,DWORD);
//WINBASEAPI BOOL WINAPI VirtualUnlock(PVOID,DWORD);
//end from winbase.h

#define PAGE_NOACCESS	0x0001
#define PAGE_READONLY	0x0002
#define PAGE_READWRITE	0x0004
#define PAGE_WRITECOPY	0x0008
#define PAGE_EXECUTE	0x0010
#define PAGE_EXECUTE_READ	0x0020
#define PAGE_EXECUTE_READWRITE	0x0040
#define PAGE_EXECUTE_WRITECOPY	0x0080
#define PAGE_GUARD		0x0100
#define PAGE_NOCACHE		0x0200
#define PAGE_WRITECOMBINE 0x0400
#define MEM_COMMIT           0x1000
#define MEM_RESERVE          0x2000
#define MEM_DECOMMIT         0x4000
#define MEM_RELEASE          0x8000
#define MEM_FREE            0x10000
#define MEM_PRIVATE         0x20000
#define MEM_MAPPED          0x40000
#define MEM_RESET           0x80000
#define MEM_TOP_DOWN       0x100000
#define MEM_WRITE_WATCH	   0x200000 /* 98/Me */
#define MEM_PHYSICAL	   0x400000
#define MEM_4MB_PAGES    0x80000000



#define NTAPI __stdcall

#ifndef NTSYSAPI
#define NTSYSAPI
#endif

#if !defined(NTSTATUS)
typedef LONG NTSTATUS;
typedef NTSTATUS *PNTSTATUS;
#endif

NTSYSAPI
NTSTATUS
NTAPI
ZwAllocateVirtualMemory (
  /*IN*/ HANDLE       ProcessHandle,
  /*IN OUT*/ PVOID    *BaseAddress,
  /*IN*/ ULONG        ZeroBits,
  /*IN OUT*/ PULONG   RegionSize,
  /*IN*/ ULONG        AllocationType,
  /*IN*/ ULONG        Protect
);

NTSYSAPI NTSTATUS ZwFreeVirtualMemory(
  /*IN*/      HANDLE  ProcessHandle,
  /*IN OUT*/  PVOID   *BaseAddress,
  /*IN OUT*/  PSIZE_T RegionSize,
  /*IN*/      ULONG   FreeType
);

NTSYSAPI
NTSTATUS
NTAPI
ZwProtectVirtualMemory(
  IN HANDLE               ProcessHandle,
  IN OUT PVOID            *BaseAddress,
  IN OUT PULONG           NumberOfBytesToProtect,
  IN ULONG                NewAccessProtection,
  OUT PULONG              OldAccessProtection );

#ifndef NtCurrentProcess
#define NtCurrentProcess() ((HANDLE)0xFFFFFFFF)
#endif // NtCurrentProcess
#ifndef NtCurrentThread
#define NtCurrentThread() ((HANDLE)0xFFFFFFFE)
#endif // NtCurrentThread

#define NtCurrentThread() ( (HANDLE)(LONG_PTR) -2 )
#define NtCurrentProcess() ( (HANDLE)(LONG_PTR) -1 )
#define ZwCurrentProcess() NtCurrentProcess()
#define ZwCurrentThread()	 NtCurrentThread()

//#define NT_SUCCESS(Status) (((NTSTATUS)(Status)) >= 0)
#ifndef NT_SUCCESS
#define NT_SUCCESS(x) ((x)>=0)
#define STATUS_SUCCESS ((NTSTATUS)0)
#endif


#define valloc(RW_SIZE)            VirtualAlloc(0, (RW_SIZE), MEM_COMMIT, PAGE_EXECUTE_READWRITE)
#define vfree(RW_PTR)              VirtualFree(((void*)(RW_PTR)), 0, MEM_RELEASE)
#define vprotect(RW_ADDR, RW_SIZE, RW_OLDPROTECT) VirtualProtect((void*)RW_ADDR,RW_SIZE,PAGE_EXECUTE_READWRITE,RW_OLDPROTECT)

#define zvalloc(RW_PTR,RW_SIZE)                    NT_SUCCESS(ZwAllocateVirtualMemory(ZwCurrentProcess(),(RW_PTR),0,(RW_SIZE),MEM_COMMIT,PAGE_EXECUTE_READWRITE))
#define zvfree(RW_PTR,RW_SIZE)                     NT_SUCCESS(ZwFreeVirtualMemory(ZwCurrentProcess(), (RW_PTR), (RW_SIZE), MEM_RELEASE))
#define zvprotect(RW_PTR, RW_SIZE, W_OLDPROTECT)  NT_SUCCESS(ZwProtectVirtualMemory(ZwCurrentProcess(),(RW_PTR),(RW_SIZE),PAGE_EXECUTE_READWRITE,W_OLDPROTECT))

#endif //MEM_BASE_FUNC_H