#ifndef ASM_FUNC_H
#define ASM_FUNC_H


#define  r8  register uint8_t
#define  r16 register uint16_t
#define  r32 register uint32_t
#define  r64 register uint64_t

#define def_asm_inc(T) volatile inline uint##T##_t asm_inc##T(r##T A){asm("inc %0" : "=r" (A) : "r" (A)); return A;}
def_asm_inc(8) def_asm_inc(16) def_asm_inc(32) def_asm_inc(64)
#define def_asm_dec(T) volatile inline uint##T##_t asm_dec##T(r##T A){asm("dec %0" : "=r" (A) : "r" (A)); return A;}
def_asm_dec(8) def_asm_dec(16) def_asm_dec(32) def_asm_dec(64)

#define def_asm_add(T) \
volatile inline uint##T##_t asm_add##T(r##T a, r##T b)\
{\
    uint##T##_t sum = 0;\
    asm\
    (\
        "add %1, %0"\
        : "=r" (sum)\
        : "r" (a), "0" (b)\
    );\
    return sum;\
} //sum = x + y;
def_asm_add(8) def_asm_add(16) def_asm_add(32) def_asm_add(64)

#endif //ASM_FUNC_H