#ifndef _SYS_PRCTL_H
#include <sys/prctl.h>

# ifndef _ISOMAC

extern int __prctl (int __option, ...);

# endif /* !_ISOMAC */
#endif
