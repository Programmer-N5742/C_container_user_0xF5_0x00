#ifndef FOR_FUNC_H
#define FOR_FUNC_H

#ifndef FOR_TYPE
#define FOR_TYPE uint64_t
#endif //FOR_TYPE
#ifndef CFOR_TYPE
#define CFOR_TYPE int64_t
#endif //CFOR_TYPE
//���� FOR ����� for
#define FOR(NAME, UPPERBND)             for(FOR_TYPE NAME = 0; NAME < UPPERBND; ++NAME)
#define NFOR(NAME, UPPERBND)            for(FOR_TYPE NAME = UPPERBND-1; NAME >= 0; --NAME)
#define CFOR(NAME, LOWERBND, UPPERBND)  for(CFOR_TYPE NAME = LOWERBND; NAME < UPPERBND; ++NAME)
#define NCFOR(NAME, UPPERBND, LOWERBND) for(CFOR_TYPE NAME = UPPERBND-1; NAME >= LOWERBND; --NAME)

#define r8FOR(MARK, VAR, COND) {VAR; MARK: if(COND){
#define r8endfor(MARK, END) END; goto MARK;}}

#define LEFOR(TYPE, NAME, LOWERBND, UPPERBND)  for(TYPE NAME = LOWERBND; NAME <= UPPERBND; ++NAME)
#define FLEFOR(TYPE, NAME, LOWERBND, UPPERBND) for(TYPE NAME = LOWERBND; NAME <= UPPERBND;){
#define endFLEFOR(NAME, UPPERBND)              if(NAME == UPPERBND) break; ++NAME;}

#define ZFLEFOR(TYPE, NAME, LOWERBND)          {TYPE NAME = LOWERBND; while(1){
#define endZFLEFOR(NAME, UPPERBND)             if(NAME == UPPERBND) break; ++NAME;}}
//#define endKFLEFOR(ENDMARK,NAME,UPPERBND)      if(NAME == UPPERBND) goto ENDMARK; ++NAME;} ENDMARK:}




//���� for ����� while
//#define for(TYPE, NAME, UPPERBND) {TYPE NAME = 0; while(NAME < UPPERBND){
//#define endfor(NAME) ++NAME;}}

//���� FOR ����� for(while)
//#define FOR(NAME, UPPERBND) for(uint64_t NAME = 0; NAME < UPPERBND; ++NAME)
//#define NFOR(NAME, UPPERBND) for(uint64_t NAME = UPPERBND-1; NAME >= 0; --NAME)
//#define CFOR(NAME, LOWERBND, UPPERBND) for(int64_t NAME = LOWERBND; NAME < UPPERBND; ++NAME)


//���� while ����� goto
//#define while(MARK, COND) {MARK: if(COND){
//#define endwhile(MARK) goto MARK;}}

//���� for ����� goto
//#define for(MARK, VARS, COND) {VARS MARK: if(COND){
//#define endfor(MARK, END) END; goto MARK;}}


//���� FOR ����� goto
//#define FOR(MARK, NAME, UPPERBND) {Iterator NAME = 0; MARK: if(NAME < UPPERBND){
//#define endFOR(MARK, NAME) ++NAME; goto MARK;}}

//EXAMPLE
//char i = 0x0; while(1){
///asm("nop\n");
//printf(format,i); /*_sleep(700);*/ 
//asm("nop\n");
//if(i == 0xFF) goto loop1end;
//++i;}loop1end:

#endif //FOR_FUNC_H