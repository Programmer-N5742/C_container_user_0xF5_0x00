#ifndef CON_FUNC_H
#define CON_FUNC_H

#define _WIN32_WINNT 0x0601//0x0500
#include <windows.h>

void hideCursor()
{
    CONSOLE_CURSOR_INFO curs = {0};
    curs.dwSize = sizeof(curs);
    curs.bVisible = FALSE;
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &curs);
}


void cls()
{
    // Get the Win32 handle representing standard output.
    // This generally only has to be done once, so we make it static.
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);

    CONSOLE_SCREEN_BUFFER_INFO csbi;
    COORD topLeft = { 0, 0 };

    // std::cout uses a buffer to batch writes to the underlying console.
    // We need to flush that to the console because we're circumventing
    // std::cout entirely; after we clear the console, we don't want
    // stale buffered text to randomly be written out.
    //std::cout.flush();

    // Figure out the current width and height of the console window
    if (!GetConsoleScreenBufferInfo(hOut, &csbi)) {
        // TODO: Handle failure!
        abort();
    }
    DWORD length = csbi.dwSize.X * csbi.dwSize.Y;

    DWORD written;

    // Flood-fill the console with spaces to clear it
    FillConsoleOutputCharacter(hOut, TEXT(' '), length, topLeft, &written);

    // Reset the attributes of every character to the default.
    // This clears all background colour formatting, if any.
    FillConsoleOutputAttribute(hOut, csbi.wAttributes, length, topLeft, &written);

    // Move the cursor back to the top left for the next sequence of writes
    SetConsoleCursorPosition(hOut, topLeft);
}



void setcur(int x, int y)//��������� ������� �� �������  x y
{
COORD coord;
coord.X = x;
coord.Y = y;
SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}




void _reclearconsole(int x, int y)
{
    for(int iy = 0; iy < y; iy++)
    {
        for(int ix = 0; ix < y; ix++)
        {
            printf("");
        }
        printf("\n");
    }
}

void setCursorPosition(int x, int y)
{
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    //std::cout.flush();
    COORD coord = { (SHORT)x, (SHORT)y };
    SetConsoleCursorPosition(hOut, coord);
}




void setConsoleColour(unsigned short colour)
{
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    //std::cout.flush();
    SetConsoleTextAttribute(hOut, colour);
}

#endif //CON_FUNC_H
