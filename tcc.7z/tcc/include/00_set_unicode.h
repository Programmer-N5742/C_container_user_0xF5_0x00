#ifndef SET_UNICODE_H
#define SET_UNICODE_H

#include <00_winver.h>

#define UNICODE
#define _WIN32_WINNT _WIN32_WINNT_WIN7
#define _T(STR) L##STR
#define TEXT(STR) L##STR
#define _S(CHAR) L##CHAR
#define SYMB(CHAR) L##CHAR



#if defined(UNICODE) && !defined(_UNICODE)
    #define _UNICODE
#elif defined(_UNICODE) && !defined(UNICODE)
    #define UNICODE
#endif

#include <tchar.h>

#define char_t char16_t
#define str_t  char_t*

#endif //SET_UNICODE_H