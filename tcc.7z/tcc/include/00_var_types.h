#ifndef VAR_TYPES_H
#define VAR_TYPES_H

#include <00__T0000.h> //([SIGN])#[TYPE]#[BITS]#"_t"
#include <00__T0000_L.h>

#endif //VAR_TYPES_H
