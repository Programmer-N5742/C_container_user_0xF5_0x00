#ifndef MAIN_TERMS_H
#define MAIN_TERMS_H

#define _0  void
#define _8  uint8_t
#define _16 uint16_t
#define _32 uint32_t
#define _64 uint64_t

#define u8  uint8_t
#define u16 uint16_t
#define u32 uint32_t
#define u64 uint64_t

#define s8  sint8_t
#define s16 sint16_t
#define s32 sint32_t
#define s64 sint64_t


/*
#define fl8  float8_t
#define fl16 float16_t
#define fl32 float32_t
#define fl64 float64_t
*/
#define fx8  fixed8_t
#define fx16 fixed16_t
#define fx32 fixed32_t
#define fx64 fixed64_t


#define logic_t   uint8_t
#define variant_t uint8_t
#define symb      uint8_t
#define cnt_t     uint64_t
#define ord_t     sint64_t
#define real_t    float64_t
#define iter_t    sint64_t

#define __ return

#define print printf
#define scan  scanf

#endif //MAIN_TERMS_H
