#ifndef MATH_BASE_OPERATIONS_H
#define MATH_BASE_OPERATIONS_H


#ifndef STATIC_ARRAY_DIMENSION_H
#define static_array_dimof(array) (sizeof(array)/sizeof(*(array)))
#endif //STATIC_ARRAY_DIMENSION_H

//Sign functions
#define ABS(a)                     (((a) >  (0))? (a) : (-(a)))
#define SIGN(a)                    (((a) == (0))? (0) : (((a) > (0))? (1) : (-1)))
#define IS_SIGN(a)                 (((a) <  (0))? (1) : (0))

//Relation functions
#define LESS(a,b)                  ((a) < (b))
#define GREATER(a,b)               ((a) > (b))
#define EQUAL(a,b)                 ((a) == (b))
#define APPROXIMATELY(a,b,epsilon) (((a) - (b)) < (epsilon))

#define MIN(a, b)                  (((a) < (b)) ? (a) : (b))
#define MAX(a, b)                  (((a) > (b)) ? (a) : (b))
#define CLAMP(a, b, c)             (MIN(MAX((a), (b)), (c)))

#define MIN3(a,b,c) MIN(MIN(a,b),c)
#define MAX3(a,b,c) MAX(MAX(a,b),c)


//Shortening functions
#define FLOOR(a)                   ((int)(a))
#define ROUND(a)                   (FLOOR((a) + (0.5f * SIGN(a))))
#define CEIL(a)                    (FLOOR((a) + (1.0f * SIGN(a))))

#define FLOOR_TO(a,precision)      (FLOOR((a) / (precision)) * (precision))
#define ROUND_TO(a,precision)      (FLOOR((a) / (precision)) * (precision))
#define CEIL_TO(a,precision)       (FLOOR((a) / (precision)) * (precision))

#define FLOOR_TO_BASE_N(a,base,precision_n)  (FLOOR((a) / (pow(base,precision_n))) * (precision_n))
#define ROUND_TO_BASE_N(a,base,precision_n)  (ROUND((a) / (pow(base,precision_n))) * (precision_n))
#define CEIL_TO_BASE_N(a,base,precision_n)   (CEIL((a)  / (pow(base,precision_n))) * (precision_n))


//Interpolation functions
#define LERP(start, end, percents) ((start) + (((end) - (start)) * (percents)))
#define lerp(start, end, percents) (LERP((start), (end), (percents)))

//Other functions
#define SQR(x)  ((x)*(x))
#define CBE(x)  ((x)*(x)*(x))
#define TTR(x)  ((x)*(x)*(x)*(x))

#define sqr(x)  (sqr(x))
#define cbe(x)  (cbe(x))
#define ttr(x)  (ttr(x))


//Other names of functions
#define TO_RANGE(a, n, b)          (CLAMP((a), (n), (b)))
#define TO_INTERVAL(a, n, b)       (CLAMP((a), (n), (b)))

#ifndef RAND_MAX
#define RAND_MAX 0x7fff
#endif //RAND_MAX
#define RAND (((real)rand())/((real)RAND_MAX)/*32767.0*/)


/*
func T    to_range(T a, T b, T c)           {return TO_RANGE(a, b, c);}
func T    round_to(T input, T roundto)      {return ROUND_TO(input, roundto);}


func T    abs(T n)                          {return ABS(n);}
func T    sign(T a)                         {return SIGN(a);}

func T    min(T n0, T n1)                   {return MIN(n0, n1);}
func T    max(T n0, T n1)                   {return MAX(n0, n1);}
func T    clamp(T n0, T n1, T n2)           {return CLAMP(n0, n1, n2);}

func T    floor(T n)                        {return FLOOR(n);}
func T    round(T n)                        {return ROUND(n);}
func T    ceil(T n)                         {return CEIL(n);}

func T    lerp(T a, T b, T c)               {return LERP(a, b, c);}

func T    sqr(T n)                          {return SQR(n);}
*/

#define defc_darr(TYPE,NAME,SIZE) uint32_t NAME##_s = SIZE; TYPE* NAME = (typeof(NAME))malloc(sizeof(*NAME)*NAME##_s)
#define defc_darr2(TYPE,NAME,SIZEA,SIZEB) uint32_t NAME##_sa = SIZEA; uint32_t NAME##_sb = SIZEB; TYPE** NAME = (typeof(NAME))malloc(sizeof(*NAME)*NAME##_sa); FOR(i,NAME##_sa) NAME[i] = (typeof(*NAME))malloc(sizeof(**NAME)*NAME##_sb);

#define def_darr(TYPE,NAME) uint32_t NAME##_s; TYPE* NAME
#define def_darr2(TYPE,NAME) uint32_t NAME##_sa; uint32_t NAME##_sb; TYPE** NAME

#define create_darr(NAME,SIZE) NAME##_s = SIZE; NAME = (typeof(NAME))malloc(sizeof(*NAME) * NAME##_s)
#define create_darr2(NAME,SIZEA,SIZEB) NAME##_sa = SIZEA; NAME##_sb = SIZEB; NAME = (typeof(NAME))malloc(sizeof(*NAME) * NAME##_sa); FOR(i,NAME##_sa) NAME[i] = (typeof(*NAME))malloc(sizeof(**NAME) * NAME##_sb)


#endif //MATH_BASE_OPERATIONS_H
