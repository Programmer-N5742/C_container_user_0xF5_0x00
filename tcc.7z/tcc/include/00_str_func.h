#ifndef STR_FUNC_H
#define STR_FUNC_H
//#include <windows.h>
strZ* fc = NULLPTR;
#include <00_strn_func.h>
#include <00_strz_func.h>

inline void strZ_cpy(char* from, char* to)
{
    ord i = 0;
    while(from[i] && to[i]) {to[i] = from[i]; ++i;}
}

strZ* strN_to_strZ(strN* str)
{
    strZ res = (typeof(res)) malloc(sizeof(*(*str).data)*(((*str).size)+1));
    FOR(i,(*str).size) res[i] = (*str).data[i];
    //str_cpy((*str).data,res);
    res[(*str).size] = 0;
    fc = res;
    return res;
}

#if defined(_X86_) || defined(__ia64__) || defined(__x86_64)
#define DECLSPEC_IMPORT __declspec(dllimport)
#else
#define DECLSPEC_IMPORT
#endif
#define WINBOOL uint8_t
#define WINBASEAPI DECLSPEC_IMPORT
//WINBASEAPI WINBOOL WINAPI  WriteConsoleA(HANDLE hConsoleOutput,CONST VOID *lpBuffer,DWORD nNumberOfCharsToWrite,PWORD lpNumberOfCharsWritten,PVOID lpReserved);


#define STD_INPUT_HANDLE (DWORD)(0xfffffff6)
#define STD_OUTPUT_HANDLE (DWORD)(0xfffffff5)
#define STD_ERROR_HANDLE (DWORD)(0xfffffff4)


#define con_init() HANDLE hStdin = GetStdHandle(STD_INPUT_HANDLE); HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE)
#define putc(CHR) WriteConsoleA(hStdout, CHR,            1, NULLPTR, NULL);
#define puts(STR) WriteConsoleA(hStdout, STR, str_len(STR), NULLPTR, NULL);


#endif //STR_FUNC_H