#ifndef STRZ_FUNC_H
#define STRZ_FUNC_H

#define lib_func inline

//#ifndef cnt_t

#define strlen      str_len
#define strequal    str_equal
#define strrepl     str_replace
#define strunionstr str_union_str
#define strunionchr str_union_chr
#define strunionchr chr_union_str
#define strsubstr   str_substr
#define strincl     str_incl

lib_func cnt_t str_len(char_t* str)
{
    cnt_t i = 0;
    while(str[i]) ++i;
    return i;
}

lib_func logic_t str_equal(const char* x, const char* y)
{
    if(strlen(x) != strlen(y)) return 0;
    logic_t t = 1;
    FOR(i,strlen(x)) t &= (x[i] == y[i]);
    return t;
}

size_t occurrences(const char* needle, const char* haystack)
{
  if(needle == NULLPTR || haystack == NULLPTR) return -1;
  char* pos = haystack;
  size_t i = 0;
  size_t l = strlen(needle);
  if(l == 0) return 0;
  while((pos = strstr(pos, needle)))
  {
    pos += l;
    i++;
  }
  return i;
}

char* str_replace(const char* str, const char* substr, const char* replace)
{
  char* pos = str;
  int count = occurrences(substr, str);
  if(0 >= count) return strdup(str);
  int size = (
        strlen(str)
      - (strlen(substr) * count)
      + strlen(replace) * count
    ) + 1;
  char* res = (char*) malloc(size);
  if(res == NULLPTR) return NULLPTR;
  memset(res, '\0', size);
  char* current;
  while((current = strstr(pos, substr)))
  {
    int len = current - pos;
    strncat(res, pos, len);
    strncat(res, replace, strlen(replace));
    pos = current + strlen(substr);
  }
  if(pos != (str + strlen(str))) strncat(res, pos, (str - pos));
  return res;
}

cnt_t str_union_length;
char* str_union_str(char* a, char* b)
{
    //P("strlen(a) = %d\n", strlen(a)); P("strlen(b) = %d\n", strlen(b));
    cnt_t res_length = strlen(a) + strlen(b);
    char* res = (typeof(res))malloc(sizeof(*res) * (res_length+1));
    //FOR(i,res_length) res[i] = 'N'; res[res_length] = 0;
    uiter_t i=0;
    uiter_t n=0; uiter_t m=0;
    while(a[n]) {res[i] = a[n]; ++i; ++n;}
    while(b[m]) {res[i] = b[m]; ++i; ++m;}
    res[i] = 0;
    str_union_length = res_length;
    return res;
}

char* str_union_chr(char* a, char b)
{
    //P("strlen(a) = %d\n", strlen(a)); P("strlen(b) = %d\n", strlen(b));
    cnt_t res_length = strlen(a)+1;
    char* res = (typeof(res))malloc(sizeof(*res) * (res_length+1));
    //FOR(i,res_length) res[i] = 'N'; res[res_length] = 0;
    uiter_t i=0;
    while(a[i]) {res[i] = a[i]; ++i;}
    res[i] = b; ++i;
    res[i] = 0;
    str_union_length = res_length;
    return res;
}

char* chr_union_str(char a, char* b)
{
    //P("strlen(a) = %d\n", strlen(a)); P("strlen(b) = %d\n", strlen(b));
    cnt_t res_length = 1+strlen(b);
    char* res = (typeof(res))malloc(sizeof(*res) * (res_length+1));
    //FOR(i,res_length) res[i] = 'N'; res[res_length] = 0;
    uiter_t i=0;
    uiter_t n=0;
    res[i] = a; ++i;
    while(b[n]) {res[i] = b[n]; ++n; ++i;}
    res[i] = 0;
    str_union_length = res_length;
    return res;
}

char* chr_union_chr(char a, char b)
{
    //P("strlen(a) = %d\n", strlen(a)); P("strlen(b) = %d\n", strlen(b));
    cnt_t res_length = 2/*1+1*/;
    char* res = (typeof(res))malloc(sizeof(*res) * (res_length+1));
    //FOR(i,res_length) res[i] = 'N'; res[res_length] = 0;
    uiter_t i=0;
    res[i] = a; ++i;
    res[i] = b; ++i;
    res[i] = 0;
    str_union_length = res_length;
    return res;
}

sint64_t str_find(char_t* in, char_t* word)
{
    int s; //iter_start
    int w; //iter_word
    logic_t t;
    s = 0;
    while(in[s])
    {
        if(word[0]==in[s])
        {
            t = 1;
            w = 0;
            while(word[w])
            {
                t &= (word[w] == in[s+w]);
                ++w;
            }
            if(t) return s;
        }
        ++s;
    }
    return -1;
}

char_t* str_substr(char_t* str, int start, int end)
{
    int res_cnt = end-start;
    char_t* res = (typeof(res)) malloc(sizeof(*res)*(res_cnt+1));
    FOR(i,res_cnt) res[i] = str[start+i];
    res[res_cnt] = 0;
    return res;
}

inline logic_t str_include(char_t* str, char_t* in)
{
    return (str_find(str,in) != -1);
}




#ifndef _FILE_DEFINED
  struct _iobuf {
    char* _ptr;
    int _cnt;
    char* _base;
    int _flag;
    int _file;
    int _charbuf;
    int _bufsiz;
    char* _tmpfname;
  };
  typedef struct _iobuf FILE;
#define _FILE_DEFINED
#endif

inline void write_file_c_fputc(FILE* out, char_t* dir, const char_t* s)
{
	//��������� ���� � �������
    out = fopen(dir, "wb");
    if(out) FOR(ch, strlen(s))
    {
        fputc(s[ch],out);
    }
    else printf("OUTPUT ERROR\n");
    fclose(out);
}

inline int write_file_c_fwrite(FILE* fp, char_t* dir, const char_t* s)
{
    size_t count = strlen(s);
	//��������� ���� � �������
    fp = fopen(dir, "wb");
    if(!fp)
    {
        printf("������ �������� %s", dir);
        return -1;
    }
    count = fwrite(s, sizeof(char_t), strlen(s), fp);
    printf("�������� %lu ����. fclose(fp) %s.\n", (unsigned long)count, fclose(fp) == 0 ? "�������" : "� �������");
    fclose(fp);
}

#endif //STRZ_FUNC_H
