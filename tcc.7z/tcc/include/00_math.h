#ifndef MATH_H
#define MATH_H

#include <00_math__constants.h>
#include <00_math__base_ops.h>
#include <00_math__arithmetic.h>

#endif //MATH_H
