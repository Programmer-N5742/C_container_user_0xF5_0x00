#ifndef TRIPLEX_H
#define TRIPLEX_H

typedef struct
{
    T1 first;
    T2 second;
    T3 third;
} ztriplex;

void ztriplex_construct(ztriplex* p, T1 a, T2 b, T3 c)
{
    (*p).first  = a;
    (*p).second = b;
    (*p).third  = c;
}

ztriplex zmake_triplex(T1 a, T2 b, T3 c)
{
    ztriplex p;
    ztriplex_construct(&p, a,b,c);
    return p;
}

#endif //TRIPLEX_H
