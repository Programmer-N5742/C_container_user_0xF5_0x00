#ifndef SET_UNICODE_H
#define SET_UNICODE_H

#include <00_winver.h>

#define ANSI
#define _WIN32_WINNT _WIN32_WINNT_WIN7
#define _T(STR) STR
#define TEXT(STR) STR
#define _S(CHAR) CHAR
#define SYMB(CHAR) CHAR

#if defined(UNICODE) && !defined(_UNICODE)
    #define _UNICODE
#elif defined(_UNICODE) && !defined(UNICODE)
    #define UNICODE
#endif

#include <tchar.h>

#define char_t char8_t
#define str_t  char_t*

#endif //SET_UNICODE_H